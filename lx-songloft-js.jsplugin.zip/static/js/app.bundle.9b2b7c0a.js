"use strict";
(() => {
  // dist/_build/static/js/app.js
  var $ = (id) => document.getElementById(id);
  var latestResults = [];
  var isLoading = false;
  var currentSource = "kw";
  var log = (value) => {
    const el = $("log");
    if (!el) return;
    el.textContent = typeof value === "string" ? value : JSON.stringify(value, null, 2);
  };
  function buildHeaders(extra = {}) {
    const headers = { "Content-Type": "application/json", ...extra };
    const token = window.SongloftPlugin?.getAuthToken?.();
    if (token) headers.Authorization = "Bearer " + token;
    return headers;
  }
  function pluginBaseUrl() {
    return window.location.pathname.split("/static/")[0].replace(/\/+$/, "");
  }
  function pluginApiUrl(path) {
    return pluginBaseUrl() + "/" + path.replace(/^\//, "");
  }
  function songloftApiUrl(path) {
    const marker = "/api/v1/jsplugin/";
    const index = window.location.pathname.indexOf(marker);
    const base = index === -1 ? "" : window.location.pathname.slice(0, index);
    return base + "/api/v1/" + path.replace(/^\/+|api\/v1\//g, "");
  }
  async function parseResponse(resp) {
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || JSON.stringify(data));
    return data;
  }
  async function request(path, options = {}) {
    const resp = await fetch(pluginApiUrl(path), {
      ...options,
      headers: buildHeaders(options.headers || {})
    });
    return parseResponse(resp);
  }
  async function songloftRequest(path, options = {}) {
    const resp = await fetch(songloftApiUrl(path), {
      ...options,
      headers: buildHeaders(options.headers || {})
    });
    return parseResponse(resp);
  }
  function dedupKey(item) {
    const raw = item.source_data?.raw || {};
    const source = item.source_data?.source || raw.source || "lx";
    const id = raw.songmid || raw.id || raw.mid || raw.hash;
    return id ? `${source}:${id}` : `${source}:${item.title}:${item.artist}:${item.album || ""}`;
  }
  function buildSourceData(item) {
    const inner = item.source_data || {};
    const songInfo = inner.raw || inner.songInfo || (item.name ? item : {});
    const source = String(songInfo.source || inner.source || inner.platform || "kw");
    const quality = window.__lxQuality || "320k";
    return JSON.stringify({
      platform: source,
      quality,
      songInfo: { ...songInfo, source }
    });
  }
  function importPayload(item) {
    return [{
      title: item.title,
      artist: item.artist || "",
      album: item.album || "",
      cover_url: item.cover_url || "",
      duration: item.duration || 0,
      plugin_entry_path: "lx-songloft-js",
      source_data: buildSourceData(item),
      dedup_key: dedupKey(item)
    }];
  }
  async function loadConfig() {
    const config = await request("/api/config");
    window.__lxQuality = config.quality || "320k";
    window.__lxConfig = config;
    currentSource = config.source || "kw";
    const sourceSelect = $("source-select");
    if (sourceSelect) sourceSelect.value = currentSource;
    const host = (config.host || "").trim();
    const token = (config.token || "").trim();
    const configured = host && token;
    const warningEl = document.getElementById("config-warning");
    const searchAreaEl = document.getElementById("search-area");
    if (warningEl && searchAreaEl) {
      if (configured) {
        warningEl.style.display = "none";
        searchAreaEl.style.display = "";
        loadHotSongs();
      } else {
        warningEl.style.display = "flex";
        searchAreaEl.style.display = "none";
      }
    }
  }
  var hotSongs = [];
  async function loadHotSongs() {
    const container = document.getElementById("hot-songs");
    if (!container) return;
    try {
      const { list } = await request(`/api/hot-search?source=${encodeURIComponent(currentSource)}`);
      hotSongs = (list || []).map((word) => ({ name: word }));
      renderHotSongs();
    } catch (err) {
      container.innerHTML = '<div class="empty-state"><p>\u52A0\u8F7D\u70ED\u95E8\u641C\u7D22\u5931\u8D25</p></div>';
    }
  }
  function renderHotSongs() {
    const container = document.getElementById("hot-songs");
    if (!container) return;
    const sourceMap = { kg: "\u9177\u72D7", kw: "\u9177\u6211", tx: "QQ", wy: "\u7F51\u6613", mg: "\u54AA\u5495" };
    const platformLabel = sourceMap[currentSource] || currentSource;
    const platformBadge = `<span class="hot-platform">${escapeHtml(platformLabel)}</span>`;
    const searchIconSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="hot-search-icon"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>';
    if (!hotSongs.length) {
      container.innerHTML = '<div class="hot-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="hot-icon"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4-6.2-4.6-6.2 4.6 2.4-7.4L2 9.4h7.6z"></path></svg>\u70ED\u95E8\u641C\u7D22' + platformBadge + '</div><div class="empty-state"><p>\u6682\u65E0\u70ED\u95E8\u641C\u7D22</p></div>';
      return;
    }
    const titleHtml = '<div class="hot-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="hot-icon"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4-6.2-4.6-6.2 4.6 2.4-7.4L2 9.4h7.6z"></path></svg>\u70ED\u95E8\u641C\u7D22' + platformBadge + "</div>";
    const songsHtml = '<div class="hot-songs-grid">' + hotSongs.map((song, index) => `
    <div class="hot-song-item" data-hot-index="${index}">
      <span class="hot-rank ${index < 3 ? "top3" : ""}">${index + 1}</span>
      <span class="hot-name">${escapeHtml(song.name || song.title || "\u672A\u77E5\u6B4C\u66F2")}</span>
      ${searchIconSvg}
    </div>
  `).join("") + "</div>";
    container.innerHTML = titleHtml + songsHtml;
  }
  function showResults() {
    const hotEl = document.getElementById("hot-songs");
    const resultsEl = document.getElementById("results");
    if (hotEl) hotEl.style.display = "none";
    if (resultsEl) resultsEl.style.display = "";
  }
  function showHotSongs() {
    const hotEl = document.getElementById("hot-songs");
    const resultsEl = document.getElementById("results");
    if (hotEl) hotEl.style.display = "";
    if (resultsEl) resultsEl.style.display = "none";
    $("keyword").value = "";
  }
  var currentKeyword = "";
  var currentPage = 1;
  var PAGE_SIZE = 20;
  var hasMore = false;
  function sourceTagHtml(item) {
    const sourceMap = { kg: "\u9177\u72D7", kw: "\u9177\u6211", tx: "QQ", wy: "\u7F51\u6613", mg: "\u54AA\u5495" };
    const source = item.source_data?.source || item.source_data?.raw?.source || "kw";
    const label = sourceMap[source] || source;
    return `<span class="source-tag source-${escapeHtml(source)}">${escapeHtml(label)}</span>`;
  }
  function songCardHtml(item, index) {
    return `
    <div class="song-card">
      <div class="song-cover">
        ${item.cover_url ? `<img src="${escapeHtml(item.cover_url)}" alt="" loading="lazy" onerror="this.parentNode.classList.add('cover-fallback');this.remove();" />` : ""}
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M9 18V5l12-2v13"></path>
          <circle cx="6" cy="18" r="3"></circle>
          <circle cx="18" cy="16" r="3"></circle>
        </svg>
      </div>
      <div class="song-info">
        <div class="song-title">${escapeHtml(item.title)}</div>
        <div class="song-meta">${sourceTagHtml(item)}${qualityBadgeHtml(item)}${escapeHtml(item.artist)} ${item.album ? " - " + escapeHtml(item.album) : ""}</div>
        <div class="song-duration">${Math.round(item.duration || 0)} \u79D2</div>
      </div>
      <button data-play-index="${index}" data-lx-play class="btn-play">\u8BD5\u542C</button>
      <button data-import-index="${index}">\u5BFC\u5165</button>
    </div>
  `;
  }
  function renderSearchResults() {
    const backBar = `
    <div class="results-back-bar">
      <button id="back-to-hot" class="btn btn-secondary btn-back">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="btn-icon">
          <path d="M19 12H5M12 19l-7-7 7-7"></path>
        </svg>
        \u8FD4\u56DE\u70ED\u95E8
      </button>
      <span class="results-count">\u641C\u7D22\u5230 ${latestResults.length} \u9996</span>
    </div>`;
    const songsHtml = latestResults.map((item, index) => songCardHtml(item, index)).join("");
    const moreBar = hasMore ? isLoading ? `<div class="load-more-bar"><span class="no-more">\u52A0\u8F7D\u4E2D...</span></div>` : `<div class="load-more-bar"><button id="load-more" class="btn btn-secondary">\u52A0\u8F7D\u66F4\u591A</button></div>` : latestResults.length ? `<div class="load-more-bar"><span class="no-more">\u6CA1\u6709\u66F4\u591A\u4E86</span></div>` : "";
    $("results").innerHTML = backBar + songsHtml + moreBar;
  }
  async function doSearch(keyword) {
    currentKeyword = keyword;
    currentPage = 1;
    showResults();
    $("results").innerHTML = '<div class="empty-state"><p>\u641C\u7D22\u4E2D...</p></div>';
    const data = await request(`/api/lx-search?keyword=${encodeURIComponent(keyword)}&page=1&limit=${PAGE_SIZE}&source=${encodeURIComponent(currentSource)}`);
    latestResults = data.results || [];
    hasMore = latestResults.length >= PAGE_SIZE;
    renderSearchResults();
    log({ count: latestResults.length });
  }
  async function loadMore() {
    if (isLoading) return;
    isLoading = true;
    const el = $("results");
    const scrollTop = el ? el.scrollTop : 0;
    renderSearchResults();
    if (el) el.scrollTop = scrollTop;
    try {
      currentPage += 1;
      const data = await request(`/api/lx-search?keyword=${encodeURIComponent(currentKeyword)}&page=${currentPage}&limit=${PAGE_SIZE}&source=${encodeURIComponent(currentSource)}`);
      const more = data.results || [];
      hasMore = more.length >= PAGE_SIZE;
      latestResults = latestResults.concat(more);
      renderSearchResults();
      log({ count: latestResults.length });
    } catch (err) {
      currentPage -= 1;
      renderSearchResults();
      log(String(err.message || err));
    } finally {
      isLoading = false;
    }
  }
  $("search").addEventListener("click", async () => {
    try {
      const keyword = $("keyword").value.trim();
      if (!keyword) {
        showHotSongs();
        return;
      }
      await doSearch(keyword);
    } catch (err) {
      log(String(err.message || err));
    }
  });
  $("keyword").addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      $("search").click();
    }
  });
  $("source-select")?.addEventListener("change", () => {
    currentSource = $("source-select").value || "kw";
    if ($("hot-songs")?.style.display !== "none") {
      loadHotSongs();
    }
  });
  function updateBackToTopButton(scrollTop) {
    const backToTop = $("back-to-top");
    if (backToTop) {
      if (scrollTop > 200) {
        backToTop.classList.add("show");
      } else {
        backToTop.classList.remove("show");
      }
    }
  }
  $("results").addEventListener("scroll", () => {
    const el = $("results");
    if (!el) return;
    const { scrollTop, scrollHeight, clientHeight } = el;
    updateBackToTopButton(scrollTop);
    if (hasMore && !isLoading) {
      if (scrollTop + clientHeight >= scrollHeight - 150) {
        loadMore();
      }
    }
  });
  $("hot-songs")?.addEventListener("scroll", () => {
    const el = $("hot-songs");
    if (!el) return;
    updateBackToTopButton(el.scrollTop);
  });
  $("back-to-top")?.addEventListener("click", () => {
    const resultsEl = $("results");
    const hotSongsEl = $("hot-songs");
    if (resultsEl && resultsEl.style.display !== "none") {
      resultsEl.scrollTo({ top: 0, behavior: "smooth" });
    } else if (hotSongsEl) {
      hotSongsEl.scrollTo({ top: 0, behavior: "smooth" });
    }
  });
  document.getElementById("hot-songs").addEventListener("click", (e) => {
    const item = e.target.closest(".hot-song-item");
    if (!item) return;
    const index = Number(item.dataset.hotIndex);
    const song = hotSongs[index];
    if (!song) return;
    const keyword = song.name || song.title || "";
    $("keyword").value = keyword;
    $("search").click();
  });
  $("results").addEventListener("click", async (event) => {
    const backBtn = event.target.closest("#back-to-hot");
    if (backBtn) {
      showHotSongs();
      return;
    }
    const moreBtn = event.target.closest("#load-more");
    if (moreBtn) {
      await loadMore();
      return;
    }
    const playBtn = event.target.closest("[data-play-index]");
    if (playBtn) {
      const item2 = latestResults[Number(playBtn.dataset.playIndex)];
      if (item2) lxPlay(item2.source_data, `${item2.title} - ${item2.artist || ""}`, playBtn, item2);
      return;
    }
    const button = event.target.closest("[data-import-index]");
    if (!button) return;
    const item = latestResults[Number(button.dataset.importIndex)];
    if (item) openImportModal(item);
  });
  var importingItem = null;
  var selectedPlaylistId = null;
  var songloftPlaylists = [];
  async function openImportModal(item) {
    importingItem = item;
    $("import-song-name").textContent = `${item.title} - ${item.artist || ""}`;
    $("import-status").innerHTML = "";
    $("playlist-name").value = "";
    $("confirm-import").disabled = false;
    document.getElementById("import-modal").style.display = "flex";
    await loadSongloftPlaylists();
  }
  function closeImportModal() {
    document.getElementById("import-modal").style.display = "none";
    importingItem = null;
  }
  async function loadSongloftPlaylists() {
    const loadingEl = $("playlist-loading");
    const selectArea = $("playlist-select-area");
    loadingEl.style.display = "block";
    selectArea.style.display = "none";
    try {
      const data = await songloftRequest("/playlists");
      songloftPlaylists = data.playlists || [];
    } catch (e) {
      songloftPlaylists = [];
    } finally {
      renderPlaylistList();
      loadingEl.style.display = "none";
      selectArea.style.display = "block";
    }
  }
  function renderPlaylistList() {
    const container = $("playlist-list");
    container.innerHTML = "";
    const noneOption = document.createElement("div");
    noneOption.className = "playlist-option";
    noneOption.dataset.id = "none";
    noneOption.innerHTML = `
    <input type="radio" name="playlist-select" value="none" id="playlist-none" />
    <span class="playlist-name">\u4EC5\u5BFC\u5165\u6B4C\u66F2\u5E93\uFF08\u4E0D\u52A0\u5165\u6B4C\u5355\uFF09</span>
  `;
    noneOption.addEventListener("click", () => selectPlaylist("none"));
    container.appendChild(noneOption);
    const newOption = document.createElement("div");
    newOption.className = "playlist-option new-playlist";
    newOption.dataset.id = "new";
    newOption.innerHTML = `
    <input type="radio" name="playlist-select" value="new" id="playlist-new" />
    <span class="playlist-name">+ \u521B\u5EFA\u65B0\u6B4C\u5355</span>
  `;
    newOption.addEventListener("click", () => selectPlaylist("new"));
    container.appendChild(newOption);
    songloftPlaylists.forEach((pl) => {
      const opt = document.createElement("div");
      opt.className = "playlist-option";
      opt.dataset.id = String(pl.id);
      opt.innerHTML = `
      <input type="radio" name="playlist-select" value="${pl.id}" id="playlist-${pl.id}" />
      <span class="playlist-name">${escapeHtml(pl.name)}</span>
    `;
      opt.addEventListener("click", () => selectPlaylist(pl.id));
      container.appendChild(opt);
    });
    selectPlaylist("none");
  }
  function selectPlaylist(id) {
    selectedPlaylistId = id;
    document.querySelectorAll("#playlist-list .playlist-option").forEach((el) => {
      el.classList.toggle("selected", String(el.dataset.id) === String(id));
      const radio = el.querySelector('input[type="radio"]');
      if (radio) radio.checked = String(el.dataset.id) === String(id);
    });
    const nameGroup = $("new-playlist-name-group");
    nameGroup.style.display = id === "new" ? "" : "none";
  }
  async function confirmImport() {
    if (!importingItem) return;
    $("confirm-import").disabled = true;
    $("import-status").innerHTML = '<div class="text-success">\u6B63\u5728\u5BFC\u5165...</div>';
    try {
      const created = await songloftRequest("/songs/remote", {
        method: "POST",
        body: JSON.stringify(importPayload(importingItem))
      });
      const createdSongs = created.songs || [];
      const songIds = createdSongs.map((s) => s.id).filter((id) => Number.isFinite(id));
      let targetName = "";
      let playlistId = null;
      if (selectedPlaylistId === "new") {
        const name = $("playlist-name").value.trim();
        if (name) {
          const createResp = await songloftRequest("/playlists", {
            method: "POST",
            body: JSON.stringify({ name, type: "normal" })
          });
          const pl = createResp.playlist || createResp;
          playlistId = pl.id;
          targetName = name;
        }
      } else if (selectedPlaylistId !== "none") {
        playlistId = Number(selectedPlaylistId);
        targetName = songloftPlaylists.find((p) => p.id === playlistId)?.name || "\u6B4C\u5355";
      }
      if (playlistId && songIds.length > 0) {
        await songloftRequest(`/playlists/${playlistId}/songs`, {
          method: "POST",
          body: JSON.stringify({ song_ids: songIds })
        });
        $("import-status").innerHTML = `<div class="text-success">\u5BFC\u5165\u6210\u529F\uFF01\u5DF2\u6DFB\u52A0\u5230\u6B4C\u5355\u300C${escapeHtml(targetName)}\u300D</div>`;
      } else {
        $("import-status").innerHTML = '<div class="text-success">\u5BFC\u5165\u6210\u529F\uFF01\u5DF2\u6DFB\u52A0\u5230\u6B4C\u66F2\u5E93</div>';
      }
      setTimeout(closeImportModal, 1500);
    } catch (err) {
      $("confirm-import").disabled = false;
      $("import-status").innerHTML = `<div class="text-error">\u5BFC\u5165\u5931\u8D25\uFF1A${escapeHtml(String(err.message || err))}</div>`;
    }
  }
  document.getElementById("cancel-import").addEventListener("click", closeImportModal);
  document.getElementById("confirm-import").addEventListener("click", confirmImport);
  document.getElementById("import-modal").addEventListener("click", (e) => {
    if (e.target.id === "import-modal") closeImportModal();
  });
  function escapeHtml(text) {
    return String(text).replace(/[&<>"]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[ch]);
  }
  function getHighestQuality(song) {
    if (!song) return null;
    const list = [];
    const collect = (t) => {
      if (!t) return;
      if (Array.isArray(t)) t.forEach((x) => {
        if (typeof x === "string") list.push(x);
        else if (x && typeof x === "object") {
          if (x.type) list.push(x.type);
          Object.keys(x).forEach((k) => {
            const v = x[k];
            if (v && (typeof v === "string" || typeof v === "number" || v === true)) list.push(k);
          });
        }
      });
      else if (typeof t === "object") {
        Object.keys(t).forEach((k) => {
          const v = t[k];
          if (v && (typeof v === "string" || typeof v === "number" || v === true)) list.push(k);
        });
      }
    };
    collect(song.types);
    collect(song._types);
    collect(song.qualitys);
    collect(song._qualitys);
    if (song.meta) {
      collect(song.meta.qualitys);
      collect(song.meta._qualitys);
      collect(song.meta.types);
    }
    if (song.HQFileHash || song.hq_hash || song["320hash"] || song.hqfilehash) list.push("320k");
    if (song.SQFileHash || song.sq_hash || song.sqhash || song.sqfilehash) list.push("flac");
    if (song.ResFileHash || song.res_hash || song.origin_hash || song.resfilehash) list.push("flac24bit");
    let sd = song.source_data;
    if (typeof sd === "string") {
      try {
        sd = JSON.parse(sd);
      } catch (e) {
        sd = null;
      }
    }
    if (sd) {
      if (typeof sd.quality === "string") list.push(sd.quality);
      const raw = sd.raw || sd.songInfo;
      if (raw) {
        collect(raw.types);
        collect(raw._types);
        collect(raw.qualitys);
        collect(raw._qualitys);
        if (raw.meta) {
          collect(raw.meta.qualitys);
          collect(raw.meta._qualitys);
          collect(raw.meta.types);
        }
        if (raw.HQFileHash || raw.hq_hash || raw["320hash"] || raw.hqfilehash) list.push("320k");
        if (raw.SQFileHash || raw.sq_hash || raw.sqhash || raw.sqfilehash) list.push("flac");
        if (raw.ResFileHash || raw.res_hash || raw.origin_hash || raw.resfilehash) list.push("flac24bit");
      }
    }
    const rank = { "128k": 1, "128": 1, "standard": 1, "320k": 2, "320": 2, "exhigh": 2, "hq": 2, "flac": 3, "lossless": 3, "sq": 3, "flac24bit": 4, "hires": 4, "hires-lossless": 4, "super": 4, "hi-res": 4 };
    let best = null, bestR = 0;
    list.filter(Boolean).forEach((t) => {
      const key = String(t).toLowerCase().replace(/^q[-_]/, "");
      const r = rank[key] || 0;
      if (r > bestR) {
        bestR = r;
        best = key;
      }
    });
    if (bestR === 1) return "128k";
    if (bestR === 2) return "320k";
    if (bestR === 3) return "flac";
    if (bestR === 4) return "flac24bit";
    return best;
  }
  function qualityBadgeHtml(song) {
    const q = getHighestQuality(song);
    if (!q) return "";
    const labels = { "128k": "128K", "320k": "320K", flac: "FLAC", flac24bit: "Hi-Res", hires: "Hi-Res" };
    const cls = q === "hires" ? "flac24bit" : q;
    return `<span class="quality-badge q-${cls}" title="\u6700\u9AD8\u53EF\u7528\u97F3\u8D28">${labels[q] || q.toUpperCase()}</span>`;
  }
  var lxCurrentBtn = null;
  function lxSetStatus(text) {
    const el = document.getElementById("lx-player-status");
    if (el) el.textContent = text;
  }
  function lxSetQuality(song) {
    const el = document.getElementById("lx-player-quality");
    if (!el) return;
    const configured = window.__lxQuality || "320k";
    const highest = getHighestQuality(song);
    const labels = { "128k": "128K", "320k": "320K", flac: "FLAC", flac24bit: "Hi-Res", hires: "Hi-Res" };
    const rank = { "128k": 1, "320k": 2, flac: 3, flac24bit: 4, hires: 4 };
    let display = configured;
    if (highest && (rank[highest] || 0) < (rank[configured] || 0)) {
      display = highest;
    }
    if (!highest) display = configured;
    const cls = display === "hires" ? "flac24bit" : display;
    el.className = "quality-badge player-quality-badge q-" + cls;
    el.textContent = labels[display] || display.toUpperCase();
    el.title = `\u5F53\u524D\u64AD\u653E\u97F3\u8D28\uFF1A${labels[display] || display}`;
    el.style.display = "";
  }
  function lxHideQuality() {
    const el = document.getElementById("lx-player-quality");
    if (el) el.style.display = "none";
  }
  function lxResetButtons() {
    document.querySelectorAll("[data-lx-play]").forEach((btn) => {
      btn.textContent = "\u8BD5\u542C";
      btn.disabled = false;
    });
  }
  function lxEnsureBar() {
    let bar = document.getElementById("lx-player-bar");
    if (bar) return bar;
    bar = document.createElement("div");
    bar.id = "lx-player-bar";
    bar.className = "player-bar";
    bar.hidden = true;
    bar.innerHTML = '<div class="player-info"><div class="player-title" id="lx-player-title">\u672A\u5728\u64AD\u653E</div><div class="player-status" id="lx-player-status"></div></div><span id="lx-player-quality" class="quality-badge player-quality-badge" style="display:none;"></span><audio id="lx-player-audio" controls preload="none"></audio><button id="lx-player-close" class="player-close" title="\u5173\u95ED">&times;</button>';
    document.body.appendChild(bar);
    const audio = bar.querySelector("#lx-player-audio");
    bar.querySelector("#lx-player-close").addEventListener("click", () => {
      audio.pause();
      audio.src = "";
      bar.hidden = true;
      lxResetButtons();
      lxHideQuality();
      lxCurrentBtn = null;
    });
    audio.addEventListener("ended", () => {
      lxSetStatus("\u64AD\u653E\u7ED3\u675F");
      lxResetButtons();
      lxHideQuality();
      lxCurrentBtn = null;
    });
    audio.addEventListener("error", () => {
      if (!audio.src) return;
      lxSetStatus("\u64AD\u653E\u5931\u8D25\uFF1A\u8BE5\u6B4C\u66F2\u53EF\u80FD\u5DF2\u5931\u6548");
      lxHideQuality();
      if (lxCurrentBtn) {
        lxCurrentBtn.textContent = "\u5931\u6548";
        lxCurrentBtn.disabled = false;
      }
    });
    return bar;
  }
  async function lxPlay(sourceData, title, btn, songItem) {
    const bar = lxEnsureBar();
    const audio = bar.querySelector("#lx-player-audio");
    lxResetButtons();
    lxCurrentBtn = btn || null;
    if (btn) {
      btn.textContent = "\u52A0\u8F7D\u4E2D...";
      btn.disabled = true;
    }
    bar.hidden = false;
    document.getElementById("lx-player-title").textContent = title || "\u672A\u77E5\u6B4C\u66F2";
    lxSetStatus("\u6B63\u5728\u83B7\u53D6\u64AD\u653E\u5730\u5740...");
    lxSetQuality(songItem || { source_data: typeof sourceData === "string" ? (() => {
      try {
        return JSON.parse(sourceData);
      } catch (e) {
        return {};
      }
    })() : sourceData });
    try {
      const data = await request("/api/music/url", {
        method: "POST",
        body: JSON.stringify({ source_data: sourceData })
      });
      if (!data.url) throw new Error("\u672A\u83B7\u53D6\u5230\u64AD\u653E\u5730\u5740");
      audio.src = data.url;
      await audio.play();
      lxSetStatus("\u64AD\u653E\u4E2D");
      if (btn) btn.textContent = "\u64AD\u653E\u4E2D";
    } catch (err) {
      lxSetStatus("\u64AD\u653E\u5931\u8D25\uFF1A\u8BE5\u6B4C\u66F2\u53EF\u80FD\u5DF2\u5931\u6548");
      lxHideQuality();
      if (btn) {
        btn.textContent = "\u5931\u6548";
        btn.disabled = false;
      }
      lxCurrentBtn = null;
      log("\u8BD5\u542C\u5931\u8D25: " + String(err.message || err));
    }
  }
  loadConfig().catch((err) => log(String(err.message || err)));
})();
