"use strict";
(() => {
  // dist/_build/static/js/app.js
  (function() {
    var BASE = "/api/v1/jsplugin/musicfree-adapter";
    function getToken() {
      var auth = JSON.parse(localStorage.getItem("songloft-auth") || "{}");
      return auth.accessToken || "";
    }
    function apiUrl(path, params) {
      var url = BASE + path;
      var token = getToken();
      if (token) {
        url += (url.indexOf("?") === -1 ? "?" : "&") + "access_token=" + encodeURIComponent(token);
      }
      if (params) {
        url += (url.indexOf("?") === -1 ? "?" : "&") + params;
      }
      return url;
    }
    function ajax(method, path, body, callback) {
      var xhr = new XMLHttpRequest();
      xhr.open(method, apiUrl(path), true);
      xhr.setRequestHeader("Accept", "application/json");
      if (body) {
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.send(JSON.stringify(body));
      } else {
        xhr.send();
      }
      xhr.onload = function() {
        try {
          callback(null, JSON.parse(xhr.responseText));
        } catch (e) {
          callback(e, null);
        }
      };
      xhr.onerror = function() {
        callback(new Error("Network error"), null);
      };
    }
    function showStatus(el, msg, isError) {
      el.innerHTML = '<div class="message ' + (isError ? "error-message" : "success-message") + '">' + msg + "</div>";
    }
    var navTabs = document.querySelectorAll(".nav-tab");
    var tabPages = document.querySelectorAll(".tab-page");
    function switchTab(name) {
      navTabs.forEach(function(t) {
        t.classList.toggle("active", t.getAttribute("data-tab") === name);
      });
      tabPages.forEach(function(p) {
        p.classList.toggle("active", p.getAttribute("data-page") === name);
      });
      if (name === "rank") loadRankLists();
      if (name === "hotsheet") loadHotSheetLists();
      if (name === "home") {
        hideRankDetail();
        hideHotSheetDetail();
        hotSongsEl.style.display = "";
        searchResultsWrap.style.display = "none";
        searchState.end = true;
        loadHotSongs();
      }
    }
    navTabs.forEach(function(tab) {
      tab.addEventListener("click", function() {
        switchTab(tab.getAttribute("data-tab"));
      });
    });
    window.goToSettings = function() {
      switchTab("settings");
    };
    var pluginListEl = document.getElementById("plugin-list");
    var noPluginTip = document.getElementById("no-plugin-tip");
    function updateNoPluginTip(plugins) {
      if (!noPluginTip) return;
      var hasEnabled = (plugins || []).some(function(p) {
        return p.enabled !== false;
      });
      noPluginTip.style.display = hasEnabled ? "none" : "";
    }
    function loadPluginList() {
      ajax("GET", "/plugins", null, function(err, data) {
        if (err || !data) {
          pluginListEl.innerHTML = '<div class="message error-message">\u52A0\u8F7D\u63D2\u4EF6\u5217\u8868\u5931\u8D25</div>';
          return;
        }
        var plugins = data.plugins || [];
        window._allPlugins = plugins;
        updateNoPluginTip(plugins);
        if (plugins.length === 0) {
          pluginListEl.innerHTML = '<div class="empty-state">\u6682\u65E0\u5DF2\u5B89\u88C5\u7684 MusicFree \u63D2\u4EF6\uFF0C\u70B9\u51FB\u53F3\u4E0A\u89D2\u300C\u6DFB\u52A0\u63D2\u4EF6\u300D\u5B89\u88C5\u3002</div>';
          return;
        }
        var html = '<div class="table-wrap"><table class="data-table plugins"><thead><tr><th>\u5E73\u53F0\u540D\u79F0</th><th>\u7248\u672C</th><th>\u529F\u80FD</th><th>\u72B6\u6001</th><th></th></tr></thead><tbody>';
        plugins.forEach(function(p) {
          var caps = p.capabilities || {};
          var features = [];
          if (caps.search) features.push("\u641C\u7D22");
          if (caps.getMediaSource) features.push("\u64AD\u653E");
          if (caps.getLyric) features.push("\u6B4C\u8BCD");
          if (caps.importMusicSheet) features.push("\u6B4C\u5355\u5BFC\u5165");
          var featStr = features.join(", ") || "\u65E0";
          var enabled = p.enabled !== false;
          var safeUrl = escapeHtml(p.url);
          var toggle = '<label class="switch" title="' + (enabled ? "\u5DF2\u542F\u7528" : "\u5DF2\u505C\u7528") + '"><input type="checkbox" ' + (enabled ? "checked" : "") + ` onchange="togglePlugin('` + safeUrl + `', this.checked)" /><span class="switch-slider"></span></label>`;
          html += '<tr class="' + (enabled ? "" : "row-disabled") + '"><td><div class="cell-title">' + escapeHtml(p.platform) + '</div><div class="cell-sub">v' + escapeHtml(p.version) + " \xB7 " + featStr + " \xB7 " + (enabled ? "\u5DF2\u542F\u7528" : "\u5DF2\u505C\u7528") + "</div></td><td>" + escapeHtml(p.version) + "</td><td>" + featStr + "</td><td>" + toggle + '</td><td class="col-op">' + (p.srcUrl ? `<button class="btn btn-small" onclick="updatePlugin('` + safeUrl + `')" style="margin-right:4px">\u66F4\u65B0</button>` : "") + `<button class="btn btn-small btn-primary" onclick="openVarsModal('` + safeUrl + "','" + escapeHtml(p.platform) + `')" style="margin-right:4px">\u53D8\u91CF</button><button class="btn btn-small btn-danger" onclick="removePlugin('` + safeUrl + `')">\u5378\u8F7D</button></td></tr>`;
        });
        html += "</tbody></table></div>";
        pluginListEl.innerHTML = html;
      });
    }
    loadPluginList();
    function escapeHtml(str) {
      if (!str) return "";
      return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }
    function topQuality(qualities) {
      if (!qualities || typeof qualities !== "object") return null;
      var order = [
        { key: "super", label: "Hi-Res" },
        { key: "high", label: "FLAC" },
        { key: "standard", label: "320K" },
        { key: "low", label: "128K" }
      ];
      for (var i = 0; i < order.length; i++) {
        var q = qualities[order[i].key];
        if (q && (typeof q === "string" || Object.keys(q).length > 0)) {
          return order[i];
        }
      }
      return null;
    }
    window.removePlugin = function(url) {
      if (!confirm("\u786E\u8BA4\u5378\u8F7D\u6B64\u63D2\u4EF6\uFF1F")) return;
      ajax("DELETE", "/plugins", { url }, function(err, data) {
        if (err || !data || !data.success) {
          showStatus(document.getElementById("plugin-list"), "\u5378\u8F7D\u5931\u8D25", true);
        } else {
          loadPluginList();
        }
      });
    };
    window.togglePlugin = function(url, enabled) {
      ajax("PUT", "/plugins", { url, enabled }, function(err, data) {
        if (err || !data || !data.success) {
          showStatus(document.getElementById("plugin-list"), "\u64CD\u4F5C\u5931\u8D25", true);
        }
        loadPluginList();
      });
    };
    window.updatePlugin = function(url) {
      ajax("PUT", "/plugins/update", { url }, function(err, data) {
        if (err || !data) {
          showToast("\u66F4\u65B0\u5931\u8D25\uFF08\u7F51\u7EDC\u9519\u8BEF\uFF09", true);
          return;
        }
        if (data.error) {
          showToast(data.error, true);
          return;
        }
        if (data.success) {
          showToast(data.platform + " \u5DF2\u4ECE v" + data.oldVersion + " \u66F4\u65B0\u5230 v" + data.newVersion);
          loadPluginList();
        }
      });
    };
    function showToast(msg, isError) {
      var el = document.createElement("div");
      el.className = "toast-message" + (isError ? " toast-error" : "");
      el.textContent = msg;
      document.body.appendChild(el);
      setTimeout(function() {
        el.classList.add("toast-fade");
        setTimeout(function() {
          el.remove();
        }, 300);
      }, 2e3);
    }
    var qualitySelect = document.getElementById("default-quality");
    var qualityStatus = document.getElementById("quality-status");
    var defaultQuality = "standard";
    function loadSettings() {
      ajax("GET", "/settings", null, function(err, data) {
        if (err || !data) return;
        defaultQuality = data.defaultQuality || "standard";
        qualitySelect.value = defaultQuality;
        gpQuality.value = defaultQuality;
      });
    }
    document.getElementById("save-quality-btn").addEventListener("click", function() {
      var q = qualitySelect.value;
      ajax("PUT", "/settings", { defaultQuality: q }, function(err, data) {
        if (err || !data || !data.success) {
          qualityStatus.innerHTML = '<div class="message error-message">\u4FDD\u5B58\u5931\u8D25</div>';
          return;
        }
        defaultQuality = q;
        gpQuality.value = q;
        qualityStatus.innerHTML = '<div class="message success-message">\u9ED8\u8BA4\u97F3\u8D28\u5DF2\u4FDD\u5B58\u4E3A ' + q + "</div>";
        setTimeout(function() {
          qualityStatus.innerHTML = "";
        }, 3e3);
      });
    });
    loadSettings();
    document.querySelector('[data-tab="settings"]').addEventListener("click", function() {
      loadSettings();
      loadExternalEndpoint();
    });
    function loadExternalEndpoint() {
      var endpointInput = document.getElementById("external-endpoint");
      var methodEl = document.getElementById("external-method");
      var statusEl = document.getElementById("external-status");
      if (!endpointInput) return;
      ajax("GET", "/external/endpoint", null, function(err, data) {
        if (err || !data) {
          endpointInput.value = "\u52A0\u8F7D\u5931\u8D25";
          return;
        }
        endpointInput.value = data.endpoint || "";
        if (methodEl && data.method) methodEl.textContent = data.method;
      });
    }
    loadExternalEndpoint();
    window.copyExternalEndpoint = function() {
      var input = document.getElementById("external-endpoint");
      var statusEl = document.getElementById("external-status");
      if (!input || !input.value) return;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(input.value).then(function() {
          showStatus(statusEl, "\u5DF2\u590D\u5236\u5230\u526A\u8D34\u677F", false);
          setTimeout(function() {
            statusEl.innerHTML = "";
          }, 2e3);
        }, function() {
          input.select();
          showStatus(statusEl, "\u8BF7\u6309 Ctrl+C \u590D\u5236", false);
        });
      } else {
        input.select();
        try {
          document.execCommand("copy");
          showStatus(statusEl, "\u5DF2\u590D\u5236\u5230\u526A\u8D34\u677F", false);
        } catch (e) {
          showStatus(statusEl, "\u8BF7\u6309 Ctrl+C \u590D\u5236", false);
        }
        setTimeout(function() {
          statusEl.innerHTML = "";
        }, 2e3);
      }
    };
    var addPluginStatus = document.getElementById("add-plugin-status");
    var selectedFile = null;
    window.openAddPluginModal = function() {
      document.getElementById("add-plugin-modal").style.display = "flex";
      document.getElementById("plugin-url-input").value = "";
      document.getElementById("plugin-file-name").textContent = "";
      document.getElementById("plugin-upload-btn").style.display = "none";
      document.getElementById("plugin-file-input").value = "";
      selectedFile = null;
      if (addPluginStatus) addPluginStatus.innerHTML = "";
    };
    window.closeAddPluginModal = function() {
      document.getElementById("add-plugin-modal").style.display = "none";
    };
    document.getElementById("add-plugin-modal").addEventListener("click", function(e) {
      if (e.target === this) closeAddPluginModal();
    });
    function installPlugin(url, force) {
      var btn = document.getElementById("plugin-url-btn");
      btn.disabled = true;
      showStatus(addPluginStatus, "\u6B63\u5728\u5B89\u88C5...", false);
      ajax("POST", "/plugins", { url, force: force === true }, function(err, data) {
        btn.disabled = false;
        if (err || !data) {
          showStatus(addPluginStatus, "\u6DFB\u52A0\u5931\u8D25\uFF08\u7F51\u7EDC\u9519\u8BEF\uFF09", true);
          return;
        }
        if (data.useForce) {
          if (confirm("\u8BE5\u63D2\u4EF6\u5DF2\u5B89\u88C5\uFF0C\u662F\u5426\u8986\u76D6\u66F4\u65B0\uFF1F")) {
            installPlugin(url, true);
          } else {
            showStatus(addPluginStatus, "\u5DF2\u53D6\u6D88", true);
          }
          return;
        }
        if (!data.success) {
          showStatus(addPluginStatus, data.error || "\u6DFB\u52A0\u5931\u8D25", true);
          return;
        }
        showStatus(addPluginStatus, "\u63D2\u4EF6 " + data.platform + " v" + data.version + " \u5B89\u88C5\u6210\u529F\uFF01");
        document.getElementById("plugin-url-input").value = "";
        loadPluginList();
      });
    }
    window.installFromUrl = function() {
      var input = document.getElementById("plugin-url-input");
      var url = (input.value || "").trim();
      if (!url) {
        showStatus(addPluginStatus, "\u8BF7\u8F93\u5165\u63D2\u4EF6 URL", true);
        return;
      }
      installPlugin(url, false);
    };
    document.getElementById("plugin-url-input").addEventListener("keydown", function(e) {
      if (e.key === "Enter") installFromUrl();
    });
    var dropZone = document.getElementById("plugin-drop-zone");
    var fileInput = document.getElementById("plugin-file-input");
    var fileNameEl = document.getElementById("plugin-file-name");
    var uploadBtn = document.getElementById("plugin-upload-btn");
    dropZone.addEventListener("click", function() {
      fileInput.click();
    });
    fileInput.addEventListener("change", function() {
      if (fileInput.files && fileInput.files[0]) {
        handleFile(fileInput.files[0]);
      }
    });
    dropZone.addEventListener("dragover", function(e) {
      e.preventDefault();
      dropZone.classList.add("dragover");
    });
    dropZone.addEventListener("dragleave", function() {
      dropZone.classList.remove("dragover");
    });
    dropZone.addEventListener("drop", function(e) {
      e.preventDefault();
      dropZone.classList.remove("dragover");
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
        handleFile(e.dataTransfer.files[0]);
      }
    });
    function handleFile(file) {
      var name = file.name || "";
      if (!/\.js$/i.test(name) && file.type !== "text/javascript") {
        showStatus(addPluginStatus, "\u8BF7\u9009\u62E9 .js \u6587\u4EF6", true);
        return;
      }
      selectedFile = file;
      fileNameEl.textContent = name + " (" + formatSize(file.size) + ")";
      uploadBtn.style.display = "";
      if (addPluginStatus) addPluginStatus.innerHTML = "";
    }
    function formatSize(bytes) {
      if (bytes < 1024) return bytes + " B";
      if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
      return (bytes / 1024 / 1024).toFixed(1) + " MB";
    }
    window.installFromFile = function() {
      if (!selectedFile) {
        showStatus(addPluginStatus, "\u8BF7\u5148\u9009\u62E9\u6587\u4EF6", true);
        return;
      }
      var reader = new FileReader();
      reader.onload = function() {
        var code = String(reader.result || "");
        if (!code) {
          showStatus(addPluginStatus, "\u6587\u4EF6\u5185\u5BB9\u4E3A\u7A7A", true);
          return;
        }
        uploadBtn.disabled = true;
        showStatus(addPluginStatus, "\u6B63\u5728\u5B89\u88C5...", false);
        ajax("POST", "/plugins", { code, force: false }, function(err, data) {
          uploadBtn.disabled = false;
          if (err || !data) {
            showStatus(addPluginStatus, "\u6DFB\u52A0\u5931\u8D25\uFF08\u7F51\u7EDC\u9519\u8BEF\uFF09", true);
            return;
          }
          if (data.useForce) {
            if (confirm("\u8BE5\u63D2\u4EF6\u5DF2\u5B89\u88C5\uFF0C\u662F\u5426\u8986\u76D6\u66F4\u65B0\uFF1F")) {
              uploadBtn.disabled = true;
              showStatus(addPluginStatus, "\u6B63\u5728\u5B89\u88C5...", false);
              ajax("POST", "/plugins", { code, force: true }, function(e2, d2) {
                uploadBtn.disabled = false;
                if (e2 || !d2 || !d2.success) {
                  showStatus(addPluginStatus, d2 && d2.error || "\u6DFB\u52A0\u5931\u8D25", true);
                  return;
                }
                showStatus(addPluginStatus, "\u63D2\u4EF6 " + d2.platform + " v" + d2.version + " \u5B89\u88C5\u6210\u529F\uFF01");
                selectedFile = null;
                fileNameEl.textContent = "";
                uploadBtn.style.display = "none";
                fileInput.value = "";
                loadPluginList();
              });
            } else {
              showStatus(addPluginStatus, "\u5DF2\u53D6\u6D88", true);
            }
            return;
          }
          if (!data.success) {
            showStatus(addPluginStatus, data.error || "\u6DFB\u52A0\u5931\u8D25", true);
            return;
          }
          showStatus(addPluginStatus, "\u63D2\u4EF6 " + data.platform + " v" + data.version + " \u5B89\u88C5\u6210\u529F\uFF01");
          selectedFile = null;
          fileNameEl.textContent = "";
          uploadBtn.style.display = "none";
          fileInput.value = "";
          loadPluginList();
        });
      };
      reader.onerror = function() {
        showStatus(addPluginStatus, "\u8BFB\u53D6\u6587\u4EF6\u5931\u8D25", true);
      };
      reader.readAsText(selectedFile);
    };
    var hotSongsEl = document.getElementById("hot-songs");
    var hotSongsGrid = document.getElementById("hot-songs-grid");
    var searchBackBtn = document.getElementById("search-back-btn");
    var searchResultsWrap = document.getElementById("search-results-wrap");
    var _hotCache = { songs: null, ts: 0 };
    function loadHotSongs(force) {
      if (!force && _hotCache.songs && Date.now() - _hotCache.ts < 3e5) {
        hotSongsGrid.innerHTML = _hotCache.html;
        window._hotSongs = _hotCache.songs;
        hotSongsEl.style.display = _hotCache.songs.length ? "" : "none";
        return;
      }
      hotSongsGrid.innerHTML = '<div class="empty-state" style="padding:12px">\u52A0\u8F7D\u4E2D...</div>';
      hotSongsEl.style.display = "";
      ajax("GET", "/top-lists", null, function(err, data) {
        if (err || !data) {
          if (!_hotCache.songs) hotSongsEl.style.display = "none";
          return;
        }
        var groups = data.groups || [];
        if (groups.length === 0 || !groups[0].items || groups[0].items.length === 0) {
          if (!_hotCache.songs) hotSongsEl.style.display = "none";
          return;
        }
        var firstGroup = groups[0];
        var firstItem = firstGroup.items[0];
        var platform = firstGroup.platform;
        var id = firstItem.id;
        ajax("GET", "/top-list-detail?platform=" + encodeURIComponent(platform) + "&id=" + encodeURIComponent(id) + "&page=1&pageSize=50", null, function(err2, data2) {
          if (err2 || !data2) {
            if (!_hotCache.songs) hotSongsEl.style.display = "none";
            return;
          }
          var songs = (data2.songs || []).slice(0, 20);
          if (songs.length === 0) {
            if (!_hotCache.songs) hotSongsEl.style.display = "none";
            return;
          }
          var html = "";
          songs.forEach(function(item, i) {
            var artist = Array.isArray(item.artist) ? item.artist.join(", ") : item.artist || "";
            var cover = item.artwork || "";
            var coverHtml = cover ? '<img class="hot-song-cover" src="' + escapeHtml(cover) + `" alt="" loading="lazy" onerror="this.style.display='none';this.nextSibling.style.display='inline-flex'" /><span class="song-cover-fallback" style="display:none">\u266B</span>` : '<span class="song-cover-fallback">\u266B</span>';
            html += '<div class="hot-song-item" onclick="searchHotSong(' + i + ')" title="\u70B9\u51FB\u641C\u7D22\u8BE5\u6B4C\u66F2">' + coverHtml + '<div class="hot-song-info"><div class="hot-song-title">' + escapeHtml(item.title) + '</div><div class="hot-song-artist">' + escapeHtml(artist) + "</div></div></div>";
          });
          _hotCache.songs = songs;
          _hotCache.html = html;
          _hotCache.ts = Date.now();
          hotSongsGrid.innerHTML = html;
          window._hotSongs = songs;
          hotSongsEl.style.display = "";
        });
      });
    }
    window.searchHotSong = function(idx) {
      var songs = window._hotSongs;
      if (!songs || !songs[idx]) return;
      searchKeyword.value = songs[idx].title;
      startSearch();
    };
    searchBackBtn.addEventListener("click", function() {
      hotSongsEl.style.display = "";
      searchResultsWrap.style.display = "none";
      searchState.end = true;
    });
    var searchBtn = document.getElementById("search-btn");
    var searchKeyword = document.getElementById("search-keyword");
    var searchResults = document.getElementById("search-results");
    var searchLoader = document.getElementById("search-loader");
    var lastResults = [];
    var searchState = { query: "", page: 1, loading: false, end: true };
    function songloftApiUrl(path) {
      var auth = JSON.parse(localStorage.getItem("songloft-auth") || "{}");
      var token = auth.accessToken || "";
      if (token) {
        path += (path.indexOf("?") === -1 ? "?" : "&") + "access_token=" + encodeURIComponent(token);
      }
      return path;
    }
    var _pickerState = { idx: -1, rowId: "", playlistId: null };
    function normalizeDuration(d) {
      if (d == null) return 0;
      if (typeof d === "string" && /^\d{1,2}:\d{2}(:\d{2})?$/.test(d.trim())) {
        var parts = d.trim().split(":").map(Number);
        if (parts.length === 2) return parts[0] * 60 + parts[1];
        if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
      }
      var n = parseFloat(d) || 0;
      if (n <= 0) return 0;
      if (n > 600) n = n / 1e3;
      return Math.round(n);
    }
    function doImport(item, btn, playlistId, cb) {
      var duration = normalizeDuration(item.duration);
      var payload = [{
        title: item.title || "",
        artist: Array.isArray(item.artist) ? item.artist.join(", ") : item.artist || "",
        album: item.album || "",
        cover_url: item.artwork || "",
        url: "",
        duration,
        dedup_key: item.id ? item.platform + ":" + item.id : "",
        plugin_entry_path: "musicfree-adapter",
        source_data: JSON.stringify(item)
      }];
      ajax("POST", "/lyric", { musicItem: item }, function(err, data) {
        var lyricText = "";
        if (!err && data && data.rawLrc) lyricText = data.rawLrc;
        payload[0].lyric = lyricText;
        var xhr = new XMLHttpRequest();
        xhr.open("POST", songloftApiUrl("/api/v1/songs/remote"), true);
        xhr.setRequestHeader("Accept", "application/json");
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.onload = function() {
          if (btn) {
            btn.disabled = false;
            btn.textContent = "\u5BFC\u5165";
          }
          try {
            var r = JSON.parse(xhr.responseText);
            if (xhr.status === 201 && r.count > 0) {
              btn.textContent = "\u5DF2\u5BFC\u5165";
              btn.classList.add("btn-imported");
              if (playlistId && r.songs && r.songs.length > 0) {
                addSongsToPlaylist(playlistId, r.songs.map(function(s) {
                  return s.id;
                }));
              }
              if (cb) cb(null, r);
            } else {
              if (cb) cb(new Error("\u5BFC\u5165\u5931\u8D25"), null);
            }
          } catch (e) {
            if (cb) cb(e, null);
          }
        };
        xhr.onerror = function() {
          if (btn) {
            btn.disabled = false;
            btn.textContent = "\u5BFC\u5165";
          }
          if (cb) cb(new Error("Network error"), null);
        };
        xhr.send(JSON.stringify(payload));
      });
    }
    function addSongsToPlaylist(playlistId, songIds) {
      var xhr = new XMLHttpRequest();
      xhr.open("POST", songloftApiUrl("/api/v1/playlists/" + playlistId + "/songs"), true);
      xhr.setRequestHeader("Accept", "application/json");
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.send(JSON.stringify({ song_ids: songIds }));
    }
    window.importToSongloft = function(idx, rowId) {
      var fromRank = rowId && rowId.indexOf("rank-song-") === 0;
      var fromHs = rowId && rowId.indexOf("hs-song-") === 0;
      var item;
      if (fromRank) {
        item = window._rankSongs && window._rankSongs[idx] ? window._rankSongs[idx] : lastResults[idx];
      } else if (fromHs) {
        item = window._hsSongs && window._hsSongs[idx] ? window._hsSongs[idx] : lastResults[idx];
      } else {
        item = lastResults[idx] ? lastResults[idx] : window._rankSongs && window._rankSongs[idx];
      }
      if (!item) return;
      _pickerState.idx = idx;
      _pickerState.rowId = rowId;
      _pickerState.playlistId = null;
      var listEl = document.getElementById("playlist-list");
      listEl.innerHTML = '<div class="empty-state">\u52A0\u8F7D\u4E2D...</div>';
      document.getElementById("playlist-modal").style.display = "flex";
      var xhr = new XMLHttpRequest();
      xhr.open("GET", songloftApiUrl("/api/v1/playlists"), true);
      xhr.setRequestHeader("Accept", "application/json");
      xhr.onload = function() {
        try {
          var data = JSON.parse(xhr.responseText);
          var playlists = data.playlists || data.data || [];
          renderPlaylistList(playlists);
        } catch (e) {
          listEl.innerHTML = '<div class="message error-message">\u52A0\u8F7D\u6B4C\u5355\u5931\u8D25</div>';
        }
      };
      xhr.onerror = function() {
        listEl.innerHTML = '<div class="message error-message">\u7F51\u7EDC\u9519\u8BEF</div>';
      };
      xhr.send();
    };
    function renderPlaylistList(playlists) {
      var listEl = document.getElementById("playlist-list");
      if (!playlists || playlists.length === 0) {
        listEl.innerHTML = '<div class="empty-state">\u6682\u65E0\u6B4C\u5355</div>';
        return;
      }
      var html = "";
      html += '<label class="playlist-item selected" data-plid=""><input type="radio" name="playlist-radio" value="" checked onchange="selectPlaylist(this.value)" /><span class="pli-name" style="color:var(--text-sub)">\u4E0D\u5BFC\u5165\u6B4C\u5355</span></label>';
      playlists.forEach(function(pl) {
        html += '<label class="playlist-item" data-plid="' + pl.id + '"><input type="radio" name="playlist-radio" value="' + pl.id + '" onchange="selectPlaylist(this.value)" /><span class="pli-name">' + escapeHtml(pl.name || "\u672A\u547D\u540D") + '</span><span class="pli-count">' + (pl.song_count || 0) + " \u9996</span></label>";
      });
      html += '<label class="playlist-item" data-plid="new" style="border-top:1px solid var(--border);margin-top:4px;color:var(--primary)"><input type="radio" name="playlist-radio" value="new" onchange="selectPlaylist(this.value)" /><span class="pli-name">+ \u521B\u5EFA\u65B0\u6B4C\u5355</span></label>';
      listEl.innerHTML = html;
    }
    window.selectPlaylist = function(val) {
      _pickerState.playlistId = val || null;
      var items = document.querySelectorAll("#playlist-list .playlist-item");
      items.forEach(function(el) {
        el.classList.remove("selected");
        if (el.getAttribute("data-plid") === String(val)) {
          el.classList.add("selected");
        }
      });
      var nameArea = document.getElementById("playlist-new-name-area");
      if (val === "new") {
        nameArea.style.display = "";
        document.getElementById("playlist-new-name").focus();
      } else {
        nameArea.style.display = "none";
      }
    };
    window.confirmPlaylistImport = function() {
      var idx = _pickerState.idx;
      var rowId = _pickerState.rowId;
      var playlistId = _pickerState.playlistId;
      if (playlistId === "new") {
        var name = document.getElementById("playlist-new-name").value.trim();
        if (!name) {
          alert("\u8BF7\u8F93\u5165\u6B4C\u5355\u540D\u79F0");
          return;
        }
      }
      closePlaylistModal();
      var fromRank = rowId && rowId.indexOf("rank-song-") === 0;
      var fromHs = rowId && rowId.indexOf("hs-song-") === 0;
      var item;
      if (fromRank) {
        item = window._rankSongs && window._rankSongs[idx] ? window._rankSongs[idx] : lastResults[idx];
      } else if (fromHs) {
        item = window._hsSongs && window._hsSongs[idx] ? window._hsSongs[idx] : lastResults[idx];
      } else {
        item = lastResults[idx] ? lastResults[idx] : window._rankSongs && window._rankSongs[idx];
      }
      if (!item) return;
      var btn = rowId ? document.querySelector("#" + rowId + " .btn-import") : null;
      if (playlistId === "new") {
        btn.disabled = true;
        btn.textContent = "\u521B\u5EFA\u6B4C\u5355...";
        var xhr = new XMLHttpRequest();
        xhr.open("POST", songloftApiUrl("/api/v1/playlists"), true);
        xhr.setRequestHeader("Accept", "application/json");
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.onload = function() {
          try {
            var pl = JSON.parse(xhr.responseText);
            if (xhr.status === 201 && pl.id) {
              btn.textContent = "\u5BFC\u5165\u4E2D...";
              doImport(item, btn, pl.id);
            } else {
              if (btn) {
                btn.disabled = false;
                btn.textContent = "\u5BFC\u5165";
              }
            }
          } catch (e) {
            if (btn) {
              btn.disabled = false;
              btn.textContent = "\u5BFC\u5165";
            }
          }
        };
        xhr.onerror = function() {
          if (btn) {
            btn.disabled = false;
            btn.textContent = "\u5BFC\u5165";
          }
        };
        xhr.send(JSON.stringify({ name, type: "normal" }));
      } else {
        if (btn) {
          btn.disabled = true;
          btn.textContent = "\u5BFC\u5165\u4E2D...";
        }
        doImport(item, btn, playlistId);
      }
    };
    window.closePlaylistModal = function() {
      document.getElementById("playlist-modal").style.display = "none";
    };
    document.getElementById("playlist-modal").addEventListener("click", function(e) {
      if (e.target === this) closePlaylistModal();
    });
    function renderSearchRows(items, startIdx) {
      var html = "";
      items.forEach(function(item, i) {
        var idx = startIdx + i;
        var artist = Array.isArray(item.artist) ? item.artist.join(", ") : item.artist;
        var q = topQuality(item.qualities);
        var qTag = q ? '<span class="quality-tag q-' + q.key + '">' + q.label + "</span>" : "";
        var cover = item.artwork || "";
        var coverHtml = cover ? '<img class="song-cover" src="' + escapeHtml(cover) + `" alt="" loading="lazy" onerror="this.style.display='none';this.nextSibling.style.display='inline-flex'" /><span class="song-cover-fallback" style="display:none">\u266B</span>` : '<span class="song-cover-fallback">\u266B</span>';
        html += '<tr id="song-row-' + idx + '"><td class="col-cover">' + coverHtml + '</td><td><div class="cell-title">' + escapeHtml(item.title) + qTag + '</div><div class="cell-sub">' + escapeHtml(artist) + " \xB7 " + escapeHtml(item.platform) + "</div></td><td>" + escapeHtml(artist) + '</td><td class="col-platform">' + escapeHtml(item.platform) + '</td><td class="col-op"><button class="btn btn-small btn-primary btn-play" onclick="playSong(' + idx + ')" style="margin-right:4px">\u64AD\u653E</button><button class="btn btn-small btn-import" onclick="importToSongloft(' + idx + ",'song-row-" + idx + `')">\u5BFC\u5165</button></td></tr>`;
      });
      return html;
    }
    function loadSearchPage() {
      if (searchState.loading || searchState.end) return;
      searchState.loading = true;
      searchLoader.style.display = "";
      ajax("GET", "/search?q=" + encodeURIComponent(searchState.query) + "&page=" + searchState.page, null, function(err, data) {
        searchState.loading = false;
        searchLoader.style.display = "none";
        if (err || !data) {
          if (searchState.page === 1) {
            searchResults.innerHTML = '<div class="message error-message">\u641C\u7D22\u5931\u8D25</div>';
            searchBtn.disabled = false;
          }
          return;
        }
        var items = data.data || [];
        if (items.length === 0) {
          searchState.end = true;
          if (searchState.page === 1) {
            searchResults.innerHTML = '<div class="empty-state">\u672A\u627E\u5230\u76F8\u5173\u7ED3\u679C</div>';
            searchBtn.disabled = false;
          }
          return;
        }
        if (searchState.page === 1) searchBtn.disabled = false;
        if (searchState.page === 1) {
          searchResults.innerHTML = '<div class="table-wrap"><table class="data-table songs"><thead><tr><th class="col-cover"></th><th>\u6B4C\u66F2\u540D</th><th>\u827A\u672F\u5BB6</th><th class="col-platform">\u6765\u6E90\u5E73\u53F0</th><th></th></tr></thead><tbody>';
        }
        var tbody = searchResults.querySelector("tbody");
        if (tbody) {
          tbody.insertAdjacentHTML("beforeend", renderSearchRows(items, lastResults.length));
        }
        Array.prototype.push.apply(lastResults, items);
        searchState.page++;
        if (data.isEnd) searchState.end = true;
      });
    }
    function startSearch() {
      var q = searchKeyword.value.trim();
      if (!q) {
        searchResults.innerHTML = '<div class="empty-state">\u8BF7\u8F93\u5165\u641C\u7D22\u5173\u952E\u8BCD</div>';
        return;
      }
      if (noPluginTip && noPluginTip.style.display !== "none") {
        searchResults.innerHTML = '<div class="empty-state">\u8BF7\u5148\u5230\u300C\u8BBE\u7F6E\u300D\u9875\u9762\u5B89\u88C5\u5E76\u542F\u7528\u63D2\u4EF6\uFF0C<a href="javascript:goToSettings()" style="color:var(--primary)">\u524D\u5F80\u8BBE\u7F6E</a></div>';
        return;
      }
      hotSongsEl.style.display = "none";
      searchResultsWrap.style.display = "";
      searchState.query = q;
      searchState.page = 1;
      searchState.loading = false;
      searchState.end = false;
      lastResults = [];
      searchBtn.disabled = true;
      searchResults.innerHTML = '<div class="empty-state">\u641C\u7D22\u4E2D...</div>';
      loadSearchPage();
    }
    searchBtn.addEventListener("click", startSearch);
    searchKeyword.addEventListener("keydown", function(e) {
      if (e.key === "Enter") startSearch();
    });
    window.addEventListener("scroll", function() {
      if (searchState.end || searchState.loading) return;
      if (searchResultsWrap.style.display === "none") return;
      if (window.innerHeight + window.scrollY >= document.body.scrollHeight - 100) {
        loadSearchPage();
      }
    });
    var player = document.getElementById("global-player");
    var gpCover = document.getElementById("gp-cover");
    var gpTitle = document.getElementById("gp-title");
    var gpArtist = document.getElementById("gp-artist");
    var gpAudio = document.getElementById("gp-audio");
    var gpQuality = document.getElementById("gp-quality");
    var gpStatus = document.getElementById("gp-status");
    var gpLyric = document.getElementById("gp-lyric");
    var currentIdx = -1;
    var lrcLines = [];
    function setStatus(msg) {
      gpStatus.textContent = msg || "";
    }
    function highlightRow(idx) {
      var prev = document.querySelector(".row-playing");
      if (prev) prev.classList.remove("row-playing");
      var row = document.getElementById("song-row-" + idx);
      if (row) row.classList.add("row-playing");
    }
    function parseLrc(text) {
      if (!text) return [];
      var lines = [];
      var lineRe = /\[(\d{1,3}):(\d{2})(?:\.(\d{2,3}))?\](.*)/g;
      var m;
      while ((m = lineRe.exec(text)) !== null) {
        var sec = parseInt(m[1], 10) * 60 + parseInt(m[2], 10) + parseInt(m[3] || "0", 10) / 1e3;
        lines.push({ time: sec, text: m[4].trim() });
      }
      lines.sort(function(a, b) {
        return a.time - b.time;
      });
      return lines;
    }
    function fetchLyric(item) {
      gpLyric.textContent = "";
      lrcLines = [];
      if (!item.platform || !item.id) return;
      ajax("POST", "/lyric", { musicItem: item }, function(err, data) {
        if (err || !data || !data.rawLrc && !data.translation) return;
        lrcLines = parseLrc(data.rawLrc || "");
      });
    }
    function updateLyric() {
      if (lrcLines.length === 0) return;
      var t = gpAudio.currentTime;
      var text = "";
      for (var i = lrcLines.length - 1; i >= 0; i--) {
        if (t >= lrcLines[i].time) {
          text = lrcLines[i].text;
          break;
        }
      }
      gpLyric.textContent = text || "";
    }
    function resolveAndPlay(item, quality) {
      setStatus("\u89E3\u6790\u4E2D...");
      player.classList.add("active");
      gpTitle.textContent = item.title || "\u672A\u77E5";
      gpArtist.textContent = Array.isArray(item.artist) ? item.artist.join(", ") : item.artist || "";
      gpCover.src = item.artwork || "";
      gpQuality.value = quality;
      lrcLines = [];
      gpLyric.textContent = "";
      fetchLyric(item);
      ajax("POST", "/source", { musicItem: item, quality }, function(err, data) {
        if (err || !data || !data.url) {
          setStatus(data && data.error || "\u65E0\u6CD5\u83B7\u53D6\u64AD\u653E\u5730\u5740");
          return;
        }
        setStatus("\u64AD\u653E\u4E2D");
        gpAudio.src = data.url;
        gpQuality.value = data.quality || quality;
        var p = gpAudio.play();
        if (p && p.catch) {
          p.catch(function() {
            setStatus("\u70B9\u51FB\u64AD\u653E\u6309\u94AE\u5F00\u59CB");
          });
        }
      });
    }
    gpAudio.addEventListener("timeupdate", updateLyric);
    window.playSong = function(idx) {
      var item = lastResults[idx];
      if (!item) return;
      currentIdx = idx;
      highlightRow(idx);
      resolveAndPlay(item, defaultQuality);
    };
    gpQuality.addEventListener("change", function() {
      if (currentIdx >= 0 && lastResults[currentIdx]) {
        resolveAndPlay(lastResults[currentIdx], gpQuality.value);
      }
    });
    gpAudio.addEventListener("error", function() {
      if (gpAudio.src) setStatus("\u64AD\u653E\u5931\u8D25");
    });
    var rankListEl = document.getElementById("rank-list");
    var rankTabsEl = document.getElementById("rank-tabs");
    var rankDetailEl = document.getElementById("rank-detail");
    var rankDetailTitle = document.getElementById("rank-detail-title");
    var rankDetailSongs = document.getElementById("rank-detail-songs");
    var allRankGroups = [];
    var currentRankPlatform = "";
    function renderRankGroups(platform) {
      var filtered = platform ? allRankGroups.filter(function(g) {
        return g.platform === platform;
      }) : allRankGroups;
      if (filtered.length === 0) {
        rankListEl.innerHTML = '<div class="empty-state">\u8BE5\u5E73\u53F0\u6682\u65E0\u699C\u5355</div>';
        return;
      }
      var html = "";
      filtered.forEach(function(group) {
        if (group.title) {
          html += '<div class="rank-group-title">' + escapeHtml(group.title) + "</div>";
        }
        html += '<div class="rank-grid">';
        (group.items || []).forEach(function(item) {
          var safeName = escapeHtml(item.title || "\u672A\u77E5");
          var safeDesc = escapeHtml(item.description || "");
          var cover = item.coverImg || "";
          var dataAttrs = 'data-platform="' + escapeHtml(item.platform || "") + '" data-id="' + escapeHtml(item.id || "") + '" data-title="' + safeName + '"';
          var extraKeys = [];
          for (var k in item) {
            if (["id", "title", "description", "coverImg", "platform"].indexOf(k) === -1) {
              extraKeys.push(k + "=" + encodeURIComponent(String(item[k])));
            }
          }
          dataAttrs += ' data-extra="' + escapeHtml(extraKeys.join("&")) + '"';
          html += '<div class="rank-card" onclick="openTopList(this)" ' + dataAttrs + '><img class="rank-card-cover" src="' + (cover || "") + '" alt="' + safeName + `" onerror="this.style.display='none';this.nextSibling.style.display='flex'" /><div class="rank-card-cover rank-card-cover-fallback" style="display:` + (cover ? "none" : "flex") + ';background:linear-gradient(135deg,#667eea,#764ba2);font-size:40px;color:rgba(255,255,255,.9)">\u266B</div><div class="rank-card-body"><h3>' + safeName + "</h3><p>" + safeDesc + "</p></div></div>";
        });
        html += "</div>";
      });
      rankListEl.innerHTML = html;
    }
    function loadRankLists() {
      rankDetailEl.style.display = "none";
      rankListEl.style.display = "";
      rankListEl.innerHTML = '<div class="empty-state">\u52A0\u8F7D\u4E2D...</div>';
      rankTabsEl.innerHTML = "";
      ajax("GET", "/top-lists", null, function(err, data) {
        if (err || !data) {
          rankListEl.innerHTML = '<div class="message error-message">\u52A0\u8F7D\u5931\u8D25</div>';
          return;
        }
        allRankGroups = data.groups || [];
        if (allRankGroups.length === 0) {
          rankListEl.innerHTML = '<div class="empty-state">\u6682\u65E0\u699C\u5355\uFF0C\u8BF7\u786E\u8BA4\u5DF2\u5B89\u88C5\u652F\u6301\u699C\u5355\u7684\u63D2\u4EF6</div>';
          return;
        }
        var platforms = [];
        var seen = {};
        allRankGroups.forEach(function(g) {
          if (!seen[g.platform]) {
            seen[g.platform] = true;
            platforms.push(g.platform);
          }
        });
        var tabsHtml = "";
        platforms.forEach(function(p) {
          tabsHtml += '<span class="rank-tab' + (p === platforms[0] ? " active" : "") + '" data-rank-platform="' + escapeHtml(p) + '">' + escapeHtml(p) + "</span>";
        });
        rankTabsEl.innerHTML = tabsHtml;
        Array.from(rankTabsEl.children).forEach(function(tab) {
          tab.addEventListener("click", function() {
            var prev = rankTabsEl.querySelector(".active");
            if (prev) prev.classList.remove("active");
            tab.classList.add("active");
            currentRankPlatform = tab.getAttribute("data-rank-platform");
            renderRankGroups(currentRankPlatform);
          });
        });
        currentRankPlatform = platforms[0];
        renderRankGroups(currentRankPlatform);
      });
    }
    var _rankCtx = { platform: "", id: "", extraStr: "", page: 1, isEnd: false, loading: false };
    window.openTopList = function(el) {
      _rankCtx.platform = el.getAttribute("data-platform");
      _rankCtx.id = el.getAttribute("data-id");
      _rankCtx.extraStr = el.getAttribute("data-extra") || "";
      _rankCtx.page = 1;
      _rankCtx.isEnd = false;
      _rankCtx.loading = false;
      var title = el.getAttribute("data-title");
      rankListEl.style.display = "none";
      rankDetailEl.style.display = "";
      rankDetailTitle.textContent = title || "\u699C\u5355\u8BE6\u60C5";
      var oldBatchBtn = document.getElementById("rank-batch-import-btn");
      if (!oldBatchBtn) {
        var hdr = document.querySelector(".rank-detail-header");
        if (hdr) {
          var bBtn = document.createElement("button");
          bBtn.className = "btn btn-small btn-import";
          bBtn.id = "rank-batch-import-btn";
          bBtn.textContent = "\u6279\u91CF\u5BFC\u5165";
          bBtn.onclick = batchImportRankSongs;
          bBtn.style.cssText = "display:none;margin-left:auto";
          hdr.appendChild(bBtn);
        }
      } else {
        oldBatchBtn.style.display = "none";
      }
      rankDetailSongs.innerHTML = '<div class="empty-state">\u52A0\u8F7D\u4E2D...</div>';
      window._rankSongs = [];
      _loadRankPage(true);
    };
    function _loadRankPage(reset) {
      if (_rankCtx.loading) return;
      if (!reset && _rankCtx.isEnd) return;
      _rankCtx.loading = true;
      if (reset) {
        rankDetailSongs.innerHTML = '<div class="empty-state">\u52A0\u8F7D\u4E2D...</div>';
        window._rankSongs = [];
        _rankCtx.page = 1;
      } else {
        var loader = document.getElementById("rank-load-more");
        if (loader) loader.textContent = "\u52A0\u8F7D\u4E2D...";
      }
      var params = "platform=" + encodeURIComponent(_rankCtx.platform) + "&id=" + encodeURIComponent(_rankCtx.id) + "&page=" + _rankCtx.page + "&pageSize=50";
      if (_rankCtx.extraStr) params += "&" + _rankCtx.extraStr;
      ajax("GET", "/top-list-detail?" + params, null, function(err, data) {
        _rankCtx.loading = false;
        if (err || !data) {
          if (reset) rankDetailSongs.innerHTML = '<div class="message error-message">\u52A0\u8F7D\u5931\u8D25</div>';
          return;
        }
        var songs = data.songs || [];
        var isEnd = data.isEnd !== false;
        if (songs.length === 0 && reset) {
          rankDetailSongs.innerHTML = '<div class="empty-state">\u8BE5\u699C\u5355\u6682\u65E0\u6B4C\u66F2</div>';
          return;
        }
        if (songs.length === 0) {
          _rankCtx.isEnd = true;
          return;
        }
        _rankCtx.isEnd = isEnd;
        _rankCtx.page++;
        var allSongs = reset ? [] : window._rankSongs;
        var startIdx = allSongs.length;
        var html = "";
        if (reset) {
          html = '<div class="table-wrap"><table class="data-table songs rank-song-table"><thead><tr><th style="width:36px"><input type="checkbox" id="rank-select-all" onchange="toggleAllRankSongs(this.checked)" /></th><th class="col-cover"></th><th>\u6B4C\u66F2\u540D</th><th>\u827A\u672F\u5BB6</th><th class="col-platform">\u6765\u6E90</th><th></th></tr></thead><tbody>';
        }
        songs.forEach(function(item, i) {
          var idx = startIdx + i;
          var artist = Array.isArray(item.artist) ? item.artist.join(", ") : item.artist;
          var q = topQuality(item.qualities);
          var qTag = q ? '<span class="quality-tag q-' + q.key + '">' + q.label + "</span>" : "";
          var cover = item.artwork || "";
          var coverHtml = cover ? '<img class="song-cover" src="' + escapeHtml(cover) + `" alt="" loading="lazy" onerror="this.style.display='none';this.nextSibling.style.display='inline-flex'" /><span class="song-cover-fallback" style="display:none">\u266B</span>` : '<span class="song-cover-fallback">\u266B</span>';
          html += '<tr id="rank-song-' + idx + '"><td style="width:36px"><input type="checkbox" class="rank-song-cb" data-idx="' + idx + '" onchange="updateRankBatchBtn()" /></td><td class="col-cover">' + coverHtml + '</td><td><div class="cell-title">' + escapeHtml(item.title) + qTag + '</div><div class="cell-sub">' + escapeHtml(artist) + " \xB7 " + escapeHtml(item.platform) + "</div></td><td>" + escapeHtml(artist) + '</td><td class="col-platform">' + escapeHtml(item.platform) + '</td><td class="col-op"><button class="btn btn-small btn-primary btn-play" onclick="playRankSong(' + idx + ')" style="margin-right:4px">\u64AD\u653E</button><button class="btn btn-small btn-import" onclick="importToSongloft(' + idx + ",'rank-song-" + idx + `')">\u5BFC\u5165</button></td></tr>`;
        });
        Array.prototype.push.apply(allSongs, songs);
        window._rankSongs = allSongs;
        if (reset) {
          html += "</tbody></table></div>";
          rankDetailSongs.innerHTML = html;
        } else {
          var tbody = document.querySelector(".rank-song-table tbody");
          if (tbody) tbody.insertAdjacentHTML("beforeend", html);
        }
        updateRankBatchBtn();
        var moreEl = document.getElementById("rank-load-more");
        if (!isEnd) {
          var moreHtml = '<div id="rank-load-more" class="empty-state" style="cursor:pointer;color:var(--primary)" onclick="window.loadMoreRankSongs()">\u70B9\u51FB\u52A0\u8F7D\u66F4\u591A</div>';
          if (reset) {
            rankDetailSongs.insertAdjacentHTML("beforeend", moreHtml);
          } else {
            if (moreEl) moreEl.textContent = "\u70B9\u51FB\u52A0\u8F7D\u66F4\u591A";
            else rankDetailSongs.insertAdjacentHTML("beforeend", moreHtml);
          }
        } else {
          if (moreEl) moreEl.remove();
        }
      });
    }
    window.loadMoreRankSongs = function() {
      _loadRankPage(false);
    };
    window.toggleAllRankSongs = function(checked) {
      var cbs = document.querySelectorAll(".rank-song-cb");
      cbs.forEach(function(cb) {
        cb.checked = checked;
      });
      updateRankBatchBtn();
    };
    window.updateRankBatchBtn = function() {
      var checked = document.querySelectorAll(".rank-song-cb:checked");
      var btn = document.getElementById("rank-batch-import-btn");
      if (btn) {
        btn.style.display = "";
        btn.textContent = checked.length > 0 ? "\u6279\u91CF\u5BFC\u5165 (" + checked.length + ")" : "\u6279\u91CF\u5BFC\u5165 (\u5168\u90E8)";
      }
    };
    window.batchImportRankSongs = function() {
      var btn = document.getElementById("rank-batch-import-btn");
      var checked = document.querySelectorAll(".rank-song-cb:checked");
      if (checked.length > 0) {
        var indices = [];
        checked.forEach(function(cb) {
          indices.push(parseInt(cb.getAttribute("data-idx"), 10));
        });
        _showBatchPickerWithIndices(indices);
      } else {
        if (!_rankCtx.isEnd) {
          if (btn) btn.textContent = "\u52A0\u8F7D\u5168\u90E8\u6B4C\u66F2...";
          _loadAllRankPages(function() {
            if (btn) btn.textContent = "\u6279\u91CF\u5BFC\u5165";
            var allIndices2 = [];
            for (var i2 = 0; i2 < (window._rankSongs || []).length; i2++) allIndices2.push(i2);
            document.querySelectorAll(".rank-song-cb").forEach(function(cb) {
              cb.checked = true;
            });
            updateRankBatchBtn();
            _showBatchPickerWithIndices(allIndices2);
          });
        } else {
          var allIndices = [];
          for (var i = 0; i < (window._rankSongs || []).length; i++) allIndices.push(i);
          _showBatchPickerWithIndices(allIndices);
        }
      }
    };
    function _showBatchPickerWithIndices(indices) {
      if (!indices || indices.length === 0) return;
      var listEl = document.getElementById("playlist-list");
      listEl.innerHTML = '<div class="empty-state">\u52A0\u8F7D\u4E2D...</div>';
      document.getElementById("playlist-modal").style.display = "flex";
      var xhr = new XMLHttpRequest();
      xhr.open("GET", songloftApiUrl("/api/v1/playlists"), true);
      xhr.setRequestHeader("Accept", "application/json");
      xhr.onload = function() {
        try {
          var data = JSON.parse(xhr.responseText);
          var playlists = data.playlists || data.data || [];
          renderPlaylistList(playlists);
          var origConfirm = window.confirmPlaylistImport;
          window.confirmPlaylistImport = function() {
            var playlistId = _pickerState.playlistId;
            if (playlistId === "new") {
              var name = document.getElementById("playlist-new-name").value.trim();
              if (!name) {
                alert("\u8BF7\u8F93\u5165\u6B4C\u5355\u540D\u79F0");
                return;
              }
            }
            closePlaylistModal();
            _runBatchImport(indices, playlistId);
            window.confirmPlaylistImport = origConfirm;
          };
        } catch (e) {
          listEl.innerHTML = '<div class="message error-message">\u52A0\u8F7D\u6B4C\u5355\u5931\u8D25</div>';
        }
      };
      xhr.onerror = function() {
        listEl.innerHTML = '<div class="message error-message">\u7F51\u7EDC\u9519\u8BEF</div>';
      };
      xhr.send();
    }
    function _loadAllRankPages(cb) {
      if (_rankCtx.isEnd || _rankCtx.loading) {
        if (cb) cb();
        return;
      }
      _rankCtx.loading = true;
      var params = "platform=" + encodeURIComponent(_rankCtx.platform) + "&id=" + encodeURIComponent(_rankCtx.id) + "&page=" + _rankCtx.page;
      if (_rankCtx.extraStr) params += "&" + _rankCtx.extraStr;
      ajax("GET", "/top-list-detail?" + params, null, function(err, data) {
        _rankCtx.loading = false;
        if (err || !data) {
          if (cb) cb();
          return;
        }
        var songs = data.songs || [];
        var isEnd = data.isEnd !== false;
        if (songs.length === 0) {
          _rankCtx.isEnd = true;
          if (cb) cb();
          return;
        }
        _rankCtx.isEnd = isEnd;
        _rankCtx.page++;
        var allSongs = window._rankSongs;
        var startIdx = allSongs.length;
        Array.prototype.push.apply(allSongs, songs);
        window._rankSongs = allSongs;
        var tbody = document.querySelector(".rank-song-table tbody");
        if (tbody) {
          var html = "";
          songs.forEach(function(item, i) {
            var idx = startIdx + i;
            var artist = Array.isArray(item.artist) ? item.artist.join(", ") : item.artist;
            var q = topQuality(item.qualities);
            var qTag = q ? '<span class="quality-tag q-' + q.key + '">' + q.label + "</span>" : "";
            var cover = item.artwork || "";
            var coverHtml = cover ? '<img class="song-cover" src="' + escapeHtml(cover) + `" alt="" loading="lazy" onerror="this.style.display='none';this.nextSibling.style.display='inline-flex'" /><span class="song-cover-fallback" style="display:none">\u266B</span>` : '<span class="song-cover-fallback">\u266B</span>';
            html += '<tr id="rank-song-' + idx + '"><td style="width:36px"><input type="checkbox" class="rank-song-cb" data-idx="' + idx + '" onchange="updateRankBatchBtn()" checked /></td><td class="col-cover">' + coverHtml + '</td><td><div class="cell-title">' + escapeHtml(item.title) + qTag + '</div><div class="cell-sub">' + escapeHtml(artist) + " \xB7 " + escapeHtml(item.platform) + "</div></td><td>" + escapeHtml(artist) + '</td><td class="col-platform">' + escapeHtml(item.platform) + '</td><td class="col-op"><button class="btn btn-small btn-primary btn-play" onclick="playRankSong(' + idx + ')" style="margin-right:4px">\u64AD\u653E</button><button class="btn btn-small btn-import" onclick="importToSongloft(' + idx + ",'rank-song-" + idx + `')">\u5BFC\u5165</button></td></tr>`;
          });
          tbody.insertAdjacentHTML("beforeend", html);
        }
        _loadAllRankPages(cb);
      });
    }
    function _showBatchPicker() {
      var totalSongs = window._rankSongs || [];
      if (totalSongs.length === 0) return;
      var indices = [];
      for (var i = 0; i < totalSongs.length; i++) indices.push(i);
      document.querySelectorAll(".rank-song-cb").forEach(function(cb) {
        cb.checked = true;
      });
      updateRankBatchBtn();
      var listEl = document.getElementById("playlist-list");
      listEl.innerHTML = '<div class="empty-state">\u52A0\u8F7D\u4E2D...</div>';
      document.getElementById("playlist-modal").style.display = "flex";
      var xhr = new XMLHttpRequest();
      xhr.open("GET", songloftApiUrl("/api/v1/playlists"), true);
      xhr.setRequestHeader("Accept", "application/json");
      xhr.onload = function() {
        try {
          var data = JSON.parse(xhr.responseText);
          var playlists = data.playlists || data.data || [];
          renderPlaylistList(playlists);
          var origConfirm = window.confirmPlaylistImport;
          window.confirmPlaylistImport = function() {
            var playlistId = _pickerState.playlistId;
            if (playlistId === "new") {
              var name = document.getElementById("playlist-new-name").value.trim();
              if (!name) {
                alert("\u8BF7\u8F93\u5165\u6B4C\u5355\u540D\u79F0");
                return;
              }
            }
            closePlaylistModal();
            _runBatchImport(indices, playlistId);
            window.confirmPlaylistImport = origConfirm;
          };
        } catch (e) {
          listEl.innerHTML = '<div class="message error-message">\u52A0\u8F7D\u6B4C\u5355\u5931\u8D25</div>';
        }
      };
      xhr.onerror = function() {
        listEl.innerHTML = '<div class="message error-message">\u7F51\u7EDC\u9519\u8BEF</div>';
      };
      xhr.send();
    }
    function _runBatchImport(indices, playlistId) {
      var songs = window._rankSongs;
      if (!songs || indices.length === 0) return;
      var total = indices.length;
      var done = 0;
      var allSongIds = [];
      var importBtn = document.getElementById("rank-batch-import-btn");
      function onComplete() {
        if (importBtn) {
          importBtn.textContent = "\u5DF2\u5BFC\u5165";
          importBtn.classList.add("btn-imported");
        }
        indices.forEach(function(idx) {
          var btn = document.querySelector("#rank-song-" + idx + " .btn-import");
          if (btn) {
            btn.textContent = "\u5DF2\u5BFC\u5165";
            btn.classList.add("btn-imported");
          }
        });
        if (playlistId && allSongIds.length > 0) {
          addSongsToPlaylist(playlistId, allSongIds);
        }
      }
      function importOne(i) {
        if (i >= indices.length) {
          onComplete();
          return;
        }
        var item = songs[indices[i]];
        if (!item) {
          importOne(i + 1);
          return;
        }
        if (importBtn) importBtn.textContent = "\u5BFC\u5165\u4E2D " + (done + 1) + "/" + total;
        var duration = normalizeDuration(item.duration);
        var payload = [{
          title: item.title || "",
          artist: Array.isArray(item.artist) ? item.artist.join(", ") : item.artist || "",
          album: item.album || "",
          cover_url: item.artwork || "",
          url: "",
          duration,
          dedup_key: item.id ? item.platform + ":" + item.id : "",
          plugin_entry_path: "musicfree-adapter",
          source_data: JSON.stringify(item)
        }];
        ajax("POST", "/lyric", { musicItem: item }, function(err, data) {
          var lyricText = "";
          if (!err && data && data.rawLrc) lyricText = data.rawLrc;
          payload[0].lyric = lyricText;
          var xhr = new XMLHttpRequest();
          xhr.open("POST", songloftApiUrl("/api/v1/songs/remote"), true);
          xhr.setRequestHeader("Accept", "application/json");
          xhr.setRequestHeader("Content-Type", "application/json");
          xhr.onload = function() {
            done++;
            try {
              var r = JSON.parse(xhr.responseText);
              if (xhr.status === 201 && r.count > 0 && r.songs) {
                r.songs.forEach(function(s) {
                  allSongIds.push(s.id);
                });
              }
            } catch (e) {
            }
            importOne(i + 1);
          };
          xhr.onerror = function() {
            done++;
            importOne(i + 1);
          };
          xhr.send(JSON.stringify(payload));
        });
      }
      function startImport() {
        importOne(0);
      }
      if (playlistId === "new") {
        if (importBtn) importBtn.textContent = "\u521B\u5EFA\u6B4C\u5355...";
        var name = document.getElementById("playlist-new-name").value.trim() || (songs[indices[0]] ? songs[indices[0]].title : "\u65B0\u6B4C\u5355");
        var createXhr = new XMLHttpRequest();
        createXhr.open("POST", songloftApiUrl("/api/v1/playlists"), true);
        createXhr.setRequestHeader("Accept", "application/json");
        createXhr.setRequestHeader("Content-Type", "application/json");
        createXhr.onload = function() {
          try {
            var pl = JSON.parse(createXhr.responseText);
            if (createXhr.status === 201 && pl.id) {
              playlistId = pl.id;
              startImport();
            } else {
              if (importBtn) importBtn.textContent = "\u521B\u5EFA\u5931\u8D25";
            }
          } catch (e) {
            if (importBtn) importBtn.textContent = "\u521B\u5EFA\u5931\u8D25";
          }
        };
        createXhr.onerror = function() {
          if (importBtn) importBtn.textContent = "\u521B\u5EFA\u5931\u8D25";
        };
        createXhr.send(JSON.stringify({ name, type: "normal" }));
      } else {
        startImport();
      }
    }
    ;
    window.playRankSong = function(idx) {
      var songs = window._rankSongs;
      if (!songs || !songs[idx]) return;
      var item = songs[idx];
      lastResults = songs;
      currentIdx = idx;
      highlightRow(idx);
      resolveAndPlay(item, defaultQuality);
    };
    function hideRankDetail() {
      rankDetailEl.style.display = "none";
      rankListEl.style.display = "";
    }
    document.getElementById("rank-back-btn").addEventListener("click", function() {
      rankDetailEl.style.display = "none";
      rankListEl.style.display = "";
    });
    var hsListEl = document.getElementById("hs-list");
    var hsTagsEl = document.getElementById("hs-tags");
    var hsDetailEl = document.getElementById("hs-detail");
    var hsDetailTitle = document.getElementById("hs-detail-title");
    var hsDetailSongs = document.getElementById("hs-detail-songs");
    var allHsGroups = [];
    var currentHsPlatform = "";
    var hsCtx = { platform: "", id: "", page: 1, isEnd: false, loading: false };
    function renderHsGroups(platform) {
      var filtered = platform ? allHsGroups.filter(function(g) {
        return g.platform === platform;
      }) : allHsGroups;
      if (filtered.length === 0) {
        hsListEl.innerHTML = '<div class="empty-state">\u8BE5\u5E73\u53F0\u6682\u65E0\u70ED\u95E8\u6B4C\u5355</div>';
        return;
      }
      var html = "";
      filtered.forEach(function(group) {
        if (group.title) {
          html += '<div class="rank-group-title">' + escapeHtml(group.title) + "</div>";
        }
        html += '<div class="rank-grid">';
        (group.items || []).forEach(function(item) {
          var safeName = escapeHtml(item.title || "\u672A\u77E5");
          var safeDesc = escapeHtml(item.description || "");
          var cover = item.coverImg || item.artwork || "";
          var dataAttrs = 'data-platform="' + escapeHtml(item.platform || "") + '" data-id="' + escapeHtml(item.id || "") + '" data-title="' + safeName + '"';
          var extraKeys = [];
          for (var k in item) {
            if (["id", "title", "description", "coverImg", "artwork", "platform"].indexOf(k) === -1) {
              extraKeys.push(k + "=" + encodeURIComponent(String(item[k])));
            }
          }
          dataAttrs += ' data-extra="' + escapeHtml(extraKeys.join("&")) + '"';
          html += '<div class="rank-card" onclick="openHotSheet(this)" ' + dataAttrs + '><img class="rank-card-cover" src="' + (cover || "") + '" alt="' + safeName + `" onerror="this.style.display='none';this.nextSibling.style.display='flex'" /><div class="rank-card-cover rank-card-cover-fallback" style="display:` + (cover ? "none" : "flex") + ';background:linear-gradient(135deg,#e74c3c,#f39c12);font-size:40px;color:rgba(255,255,255,.9)">\u{1F4CB}</div><div class="rank-card-body"><h3>' + safeName + "</h3><p>" + safeDesc + "</p></div></div>";
        });
        html += "</div>";
      });
      hsListEl.innerHTML = html;
    }
    function loadHotSheetLists() {
      hsDetailEl.style.display = "none";
      hsListEl.style.display = "";
      hsListEl.innerHTML = '<div class="empty-state">\u52A0\u8F7D\u4E2D...</div>';
      hsTagsEl.innerHTML = "";
      ajax("GET", "/recommend-sheets", null, function(err, data) {
        if (err || !data) {
          hsListEl.innerHTML = '<div class="message error-message">\u52A0\u8F7D\u5931\u8D25</div>';
          return;
        }
        allHsGroups = data.groups || [];
        if (allHsGroups.length === 0) {
          hsListEl.innerHTML = '<div class="empty-state">\u6682\u65E0\u70ED\u95E8\u6B4C\u5355\uFF0C\u8BF7\u786E\u8BA4\u5DF2\u5B89\u88C5\u652F\u6301\u70ED\u95E8\u6B4C\u5355\u7684\u63D2\u4EF6</div>';
          return;
        }
        var platforms = [];
        var seen = {};
        allHsGroups.forEach(function(g) {
          if (!seen[g.platform]) {
            seen[g.platform] = true;
            platforms.push(g.platform);
          }
        });
        var tabsHtml = "";
        platforms.forEach(function(p) {
          tabsHtml += '<span class="rank-tab' + (p === platforms[0] ? " active" : "") + '" data-hs-platform="' + escapeHtml(p) + '">' + escapeHtml(p) + "</span>";
        });
        hsTagsEl.innerHTML = tabsHtml;
        Array.from(hsTagsEl.children).forEach(function(tab) {
          tab.addEventListener("click", function() {
            var prev = hsTagsEl.querySelector(".active");
            if (prev) prev.classList.remove("active");
            tab.classList.add("active");
            currentHsPlatform = tab.getAttribute("data-hs-platform");
            renderHsGroups(currentHsPlatform);
          });
        });
        currentHsPlatform = platforms[0];
        renderHsGroups(currentHsPlatform);
      });
    }
    window.openHotSheet = function(el) {
      hsCtx.platform = el.getAttribute("data-platform");
      hsCtx.id = el.getAttribute("data-id");
      hsCtx.extraStr = el.getAttribute("data-extra") || "";
      hsCtx.page = 1;
      hsCtx.isEnd = false;
      hsCtx.loading = false;
      var title = el.getAttribute("data-title");
      hsListEl.style.display = "none";
      hsDetailEl.style.display = "";
      hsDetailTitle.textContent = title || "\u6B4C\u5355\u8BE6\u60C5";
      var oldBatchBtn = document.getElementById("hs-batch-import-btn");
      if (!oldBatchBtn) {
        var hdr = document.querySelector("#hs-detail .rank-detail-header");
        if (hdr) {
          var bBtn = document.createElement("button");
          bBtn.className = "btn btn-small btn-import";
          bBtn.id = "hs-batch-import-btn";
          bBtn.textContent = "\u6279\u91CF\u5BFC\u5165";
          bBtn.onclick = batchImportHsSongs;
          bBtn.style.cssText = "display:none;margin-left:auto";
          hdr.appendChild(bBtn);
        }
      } else {
        oldBatchBtn.style.display = "none";
      }
      hsDetailSongs.innerHTML = '<div class="empty-state">\u52A0\u8F7D\u4E2D...</div>';
      window._hsSongs = [];
      _loadHsPage(true);
    };
    function _loadHsPage(reset) {
      if (hsCtx.loading) return;
      if (!reset && hsCtx.isEnd) return;
      hsCtx.loading = true;
      if (reset) {
        hsDetailSongs.innerHTML = '<div class="empty-state">\u52A0\u8F7D\u4E2D...</div>';
        window._hsSongs = [];
        hsCtx.page = 1;
      } else {
        var loader = document.getElementById("hs-load-more");
        if (loader) loader.textContent = "\u52A0\u8F7D\u4E2D...";
      }
      var params = "platform=" + encodeURIComponent(hsCtx.platform) + "&id=" + encodeURIComponent(hsCtx.id) + "&page=" + hsCtx.page + "&pageSize=50";
      if (hsCtx.extraStr) params += "&" + hsCtx.extraStr;
      ajax("GET", "/recommend-sheets/detail?" + params, null, function(err, data) {
        hsCtx.loading = false;
        if (err || !data) {
          if (reset) hsDetailSongs.innerHTML = '<div class="message error-message">\u52A0\u8F7D\u5931\u8D25</div>';
          return;
        }
        var songs = data.songs || [];
        var isEnd = data.isEnd !== false;
        if (songs.length === 0 && reset) {
          hsDetailSongs.innerHTML = '<div class="empty-state">\u8BE5\u6B4C\u5355\u6682\u65E0\u5185\u5BB9</div>';
          return;
        }
        if (songs.length === 0) {
          hsCtx.isEnd = true;
          return;
        }
        hsCtx.isEnd = isEnd;
        hsCtx.page++;
        var allSongs = reset ? [] : window._hsSongs;
        var startIdx = allSongs.length;
        var html = "";
        if (reset) {
          html = '<div class="table-wrap"><table class="data-table songs hs-song-table"><thead><tr><th style="width:36px"><input type="checkbox" id="hs-select-all" onchange="toggleAllHsSongs(this.checked)" /></th><th class="col-cover"></th><th>\u6B4C\u66F2\u540D</th><th>\u827A\u672F\u5BB6</th><th class="col-platform">\u6765\u6E90</th><th></th></tr></thead><tbody>';
        }
        songs.forEach(function(item, i) {
          var idx = startIdx + i;
          var artist = Array.isArray(item.artist) ? item.artist.join(", ") : item.artist || "";
          var cover = item.artwork || "";
          var coverHtml = cover ? '<img class="song-cover" src="' + escapeHtml(cover) + `" alt="" loading="lazy" onerror="this.style.display='none';this.nextSibling.style.display='inline-flex'" /><span class="song-cover-fallback" style="display:none">\u266B</span>` : '<span class="song-cover-fallback">\u266B</span>';
          html += '<tr id="hs-song-' + idx + '"><td style="width:36px"><input type="checkbox" class="hs-song-cb" data-idx="' + idx + '" onchange="updateHsBatchBtn()" /></td><td class="col-cover">' + coverHtml + '</td><td><div class="cell-title">' + escapeHtml(item.title) + '</div><div class="cell-sub">' + escapeHtml(artist) + " \xB7 " + escapeHtml(item.platform) + "</div></td><td>" + escapeHtml(artist) + '</td><td class="col-platform">' + escapeHtml(item.platform) + '</td><td class="col-op"><button class="btn btn-small btn-primary btn-play" onclick="playHsSong(' + idx + ')" style="margin-right:4px">\u64AD\u653E</button><button class="btn btn-small btn-import" onclick="importToSongloft(' + idx + ",'hs-song-" + idx + `')">\u5BFC\u5165</button></td></tr>`;
        });
        Array.prototype.push.apply(allSongs, songs);
        window._hsSongs = allSongs;
        if (reset) {
          html += "</tbody></table></div>";
          hsDetailSongs.innerHTML = html;
        } else {
          var tbody = document.querySelector(".hs-song-table tbody");
          if (tbody) tbody.insertAdjacentHTML("beforeend", html);
        }
        updateHsBatchBtn();
        var moreEl = document.getElementById("hs-load-more");
        if (!isEnd) {
          var moreHtml = '<div id="hs-load-more" class="empty-state" style="cursor:pointer;color:var(--primary)" onclick="loadMoreHsSongs()">\u70B9\u51FB\u52A0\u8F7D\u66F4\u591A</div>';
          if (reset) {
            hsDetailSongs.insertAdjacentHTML("beforeend", moreHtml);
          } else {
            if (moreEl) moreEl.textContent = "\u70B9\u51FB\u52A0\u8F7D\u66F4\u591A";
            else hsDetailSongs.insertAdjacentHTML("beforeend", moreHtml);
          }
        } else {
          if (moreEl) moreEl.remove();
        }
      });
    }
    window.playHsSong = function(idx) {
      var songs = window._hsSongs;
      if (!songs || !songs[idx]) return;
      lastResults = songs;
      currentIdx = idx;
      resolveAndPlay(songs[idx], defaultQuality);
    };
    window.toggleAllHsSongs = function(checked) {
      var cbs = document.querySelectorAll(".hs-song-cb");
      cbs.forEach(function(cb) {
        cb.checked = checked;
      });
      updateHsBatchBtn();
    };
    window.updateHsBatchBtn = function() {
      var checked = document.querySelectorAll(".hs-song-cb:checked");
      var btn = document.getElementById("hs-batch-import-btn");
      if (btn) {
        btn.style.display = "";
        btn.textContent = checked.length > 0 ? "\u6279\u91CF\u5BFC\u5165 (" + checked.length + ")" : "\u6279\u91CF\u5BFC\u5165 (\u5168\u90E8)";
      }
    };
    window.loadMoreHsSongs = function() {
      _loadHsPage(false);
    };
    window.batchImportHsSongs = function() {
      var btn = document.getElementById("hs-batch-import-btn");
      var checked = document.querySelectorAll(".hs-song-cb:checked");
      if (checked.length > 0) {
        var indices = [];
        checked.forEach(function(cb) {
          indices.push(parseInt(cb.getAttribute("data-idx"), 10));
        });
        _showHsBatchPickerWithIndices(indices);
      } else {
        if (!hsCtx.isEnd) {
          if (btn) btn.textContent = "\u52A0\u8F7D\u5168\u90E8\u6B4C\u66F2...";
          _loadAllHsPages(function() {
            if (btn) btn.textContent = "\u6279\u91CF\u5BFC\u5165";
            var allIndices2 = [];
            for (var i2 = 0; i2 < (window._hsSongs || []).length; i2++) allIndices2.push(i2);
            document.querySelectorAll(".hs-song-cb").forEach(function(cb) {
              cb.checked = true;
            });
            updateHsBatchBtn();
            _showHsBatchPickerWithIndices(allIndices2);
          });
        } else {
          var allIndices = [];
          for (var i = 0; i < (window._hsSongs || []).length; i++) allIndices.push(i);
          _showHsBatchPickerWithIndices(allIndices);
        }
      }
    };
    function _loadAllHsPages(cb) {
      if (hsCtx.isEnd || hsCtx.loading) {
        if (cb) cb();
        return;
      }
      hsCtx.loading = true;
      var params = "platform=" + encodeURIComponent(hsCtx.platform) + "&id=" + encodeURIComponent(hsCtx.id) + "&page=" + hsCtx.page + "&pageSize=50";
      if (hsCtx.extraStr) params += "&" + hsCtx.extraStr;
      ajax("GET", "/recommend-sheets/detail?" + params, null, function(err, data) {
        hsCtx.loading = false;
        if (err || !data) {
          if (cb) cb();
          return;
        }
        var songs = data.songs || [];
        var isEnd = data.isEnd !== false;
        if (songs.length === 0) {
          hsCtx.isEnd = true;
          if (cb) cb();
          return;
        }
        hsCtx.isEnd = isEnd;
        hsCtx.page++;
        var allSongs = window._hsSongs;
        var startIdx = allSongs.length;
        Array.prototype.push.apply(allSongs, songs);
        window._hsSongs = allSongs;
        var tbody = document.querySelector(".hs-song-table tbody");
        if (tbody) {
          var html = "";
          songs.forEach(function(item, i) {
            var idx = startIdx + i;
            var artist = Array.isArray(item.artist) ? item.artist.join(", ") : item.artist || "";
            var cover = item.artwork || "";
            var coverHtml = cover ? '<img class="song-cover" src="' + escapeHtml(cover) + `" alt="" loading="lazy" onerror="this.style.display='none';this.nextSibling.style.display='inline-flex'" /><span class="song-cover-fallback" style="display:none">\u266B</span>` : '<span class="song-cover-fallback">\u266B</span>';
            html += '<tr id="hs-song-' + idx + '"><td style="width:36px"><input type="checkbox" class="hs-song-cb" data-idx="' + idx + '" onchange="updateHsBatchBtn()" checked /></td><td class="col-cover">' + coverHtml + '</td><td><div class="cell-title">' + escapeHtml(item.title) + '</div><div class="cell-sub">' + escapeHtml(artist) + " \xB7 " + escapeHtml(item.platform) + "</div></td><td>" + escapeHtml(artist) + '</td><td class="col-platform">' + escapeHtml(item.platform) + '</td><td class="col-op"><button class="btn btn-small btn-primary btn-play" onclick="playHsSong(' + idx + ')" style="margin-right:4px">\u64AD\u653E</button><button class="btn btn-small btn-import" onclick="importToSongloft(' + idx + ",'hs-song-" + idx + `')">\u5BFC\u5165</button></td></tr>`;
          });
          tbody.insertAdjacentHTML("beforeend", html);
        }
        _loadAllHsPages(cb);
      });
    }
    function _showHsBatchPickerWithIndices(indices) {
      if (!indices || indices.length === 0) return;
      var listEl = document.getElementById("playlist-list");
      listEl.innerHTML = '<div class="empty-state">\u52A0\u8F7D\u4E2D...</div>';
      document.getElementById("playlist-modal").style.display = "flex";
      var xhr = new XMLHttpRequest();
      xhr.open("GET", songloftApiUrl("/api/v1/playlists"), true);
      xhr.setRequestHeader("Accept", "application/json");
      xhr.onload = function() {
        try {
          var data = JSON.parse(xhr.responseText);
          var playlists = data.playlists || data.data || [];
          renderPlaylistList(playlists);
          var origConfirm = window.confirmPlaylistImport;
          window.confirmPlaylistImport = function() {
            var playlistId = _pickerState.playlistId;
            if (playlistId === "new") {
              var name = document.getElementById("playlist-new-name").value.trim();
              if (!name) {
                alert("\u8BF7\u8F93\u5165\u6B4C\u5355\u540D\u79F0");
                return;
              }
            }
            closePlaylistModal();
            _runHsBatchImport(indices, playlistId);
            window.confirmPlaylistImport = origConfirm;
          };
        } catch (e) {
          listEl.innerHTML = '<div class="message error-message">\u52A0\u8F7D\u6B4C\u5355\u5931\u8D25</div>';
        }
      };
      xhr.onerror = function() {
        listEl.innerHTML = '<div class="message error-message">\u7F51\u7EDC\u9519\u8BEF</div>';
      };
      xhr.send();
    }
    function _runHsBatchImport(indices, playlistId) {
      var songs = window._hsSongs;
      if (!songs || indices.length === 0) return;
      var total = indices.length;
      var done = 0;
      var allSongIds = [];
      var importBtn = document.getElementById("hs-batch-import-btn");
      function onComplete() {
        if (importBtn) {
          importBtn.textContent = "\u5DF2\u5BFC\u5165";
          importBtn.classList.add("btn-imported");
        }
        indices.forEach(function(idx) {
          var btn = document.querySelector("#hs-song-" + idx + " .btn-import");
          if (btn) {
            btn.textContent = "\u5DF2\u5BFC\u5165";
            btn.classList.add("btn-imported");
          }
        });
        if (playlistId && allSongIds.length > 0) {
          addSongsToPlaylist(playlistId, allSongIds);
        }
      }
      function importOne(i) {
        if (i >= indices.length) {
          onComplete();
          return;
        }
        var item = songs[indices[i]];
        if (!item) {
          importOne(i + 1);
          return;
        }
        if (importBtn) importBtn.textContent = "\u5BFC\u5165\u4E2D " + (done + 1) + "/" + total;
        var duration = normalizeDuration(item.duration);
        var payload = [{
          title: item.title || "",
          artist: Array.isArray(item.artist) ? item.artist.join(", ") : item.artist || "",
          album: item.album || "",
          cover_url: item.artwork || "",
          url: "",
          duration,
          dedup_key: item.id ? item.platform + ":" + item.id : "",
          plugin_entry_path: "musicfree-adapter",
          source_data: JSON.stringify(item)
        }];
        ajax("POST", "/lyric", { musicItem: item }, function(err, data) {
          var lyricText = "";
          if (!err && data && data.rawLrc) lyricText = data.rawLrc;
          payload[0].lyric = lyricText;
          var xhr = new XMLHttpRequest();
          xhr.open("POST", songloftApiUrl("/api/v1/songs/remote"), true);
          xhr.setRequestHeader("Accept", "application/json");
          xhr.setRequestHeader("Content-Type", "application/json");
          xhr.onload = function() {
            done++;
            try {
              var r = JSON.parse(xhr.responseText);
              if (xhr.status === 201 && r.count > 0 && r.songs) {
                r.songs.forEach(function(s) {
                  allSongIds.push(s.id);
                });
              }
            } catch (e) {
            }
            importOne(i + 1);
          };
          xhr.onerror = function() {
            done++;
            importOne(i + 1);
          };
          xhr.send(JSON.stringify(payload));
        });
      }
      function startImport() {
        importOne(0);
      }
      if (playlistId === "new") {
        if (importBtn) importBtn.textContent = "\u521B\u5EFA\u6B4C\u5355...";
        var name = document.getElementById("playlist-new-name").value.trim() || (songs[indices[0]] ? songs[indices[0]].title : "\u65B0\u6B4C\u5355");
        var createXhr = new XMLHttpRequest();
        createXhr.open("POST", songloftApiUrl("/api/v1/playlists"), true);
        createXhr.setRequestHeader("Accept", "application/json");
        createXhr.setRequestHeader("Content-Type", "application/json");
        createXhr.onload = function() {
          try {
            var pl = JSON.parse(createXhr.responseText);
            if (createXhr.status === 201 && pl.id) {
              playlistId = pl.id;
              startImport();
            } else {
              if (importBtn) importBtn.textContent = "\u521B\u5EFA\u5931\u8D25";
            }
          } catch (e) {
            if (importBtn) importBtn.textContent = "\u521B\u5EFA\u5931\u8D25";
          }
        };
        createXhr.onerror = function() {
          if (importBtn) importBtn.textContent = "\u521B\u5EFA\u5931\u8D25";
        };
        createXhr.send(JSON.stringify({ name, type: "normal" }));
      } else {
        startImport();
      }
    }
    function hideHotSheetDetail() {
      hsDetailEl.style.display = "none";
      hsListEl.style.display = "";
      var batchBtn = document.getElementById("hs-batch-import-btn");
      if (batchBtn) batchBtn.style.display = "none";
    }
    document.getElementById("hs-back-btn").addEventListener("click", function() {
      hsDetailEl.style.display = "none";
      hsListEl.style.display = "";
    });
    var editingVarsUrl = "";
    window.openVarsModal = function(url, platform) {
      editingVarsUrl = url;
      document.getElementById("vars-modal-title").textContent = "\u53D8\u91CF\u8BBE\u7F6E - " + platform;
      document.getElementById("vars-editor").value = "";
      document.getElementById("vars-status").innerHTML = "";
      document.getElementById("vars-modal").style.display = "flex";
      ajax("GET", "/plugin-vars?url=" + encodeURIComponent(url), null, function(err, data) {
        if (err || !data || data.error) {
          document.getElementById("vars-editor").value = '{\n  "error": "\u65E0\u6CD5\u52A0\u8F7D\u53D8\u91CF"\n}';
          return;
        }
        document.getElementById("vars-editor").value = JSON.stringify(data.variables || {}, null, 2);
      });
    };
    window.closeVarsModal = function() {
      document.getElementById("vars-modal").style.display = "none";
      editingVarsUrl = "";
    };
    window.saveVars = function() {
      var text = document.getElementById("vars-editor").value.trim();
      var varsEl = document.getElementById("vars-status");
      var saveBtn = document.getElementById("vars-save-btn");
      try {
        var parsed = text ? JSON.parse(text) : {};
        if (typeof parsed !== "object" || Array.isArray(parsed)) {
          throw new Error("\u5FC5\u987B\u662F\u4E00\u4E2A JSON \u5BF9\u8C61");
        }
        saveBtn.disabled = true;
        ajax("PUT", "/plugin-vars", { url: editingVarsUrl, variables: parsed }, function(err, data) {
          saveBtn.disabled = false;
          if (err || !data || !data.success) {
            varsEl.innerHTML = '<div class="message error-message">\u4FDD\u5B58\u5931\u8D25</div>';
          } else {
            varsEl.innerHTML = '<div class="message success-message">\u4FDD\u5B58\u6210\u529F</div>';
          }
        });
      } catch (e) {
        varsEl.innerHTML = '<div class="message error-message">JSON \u683C\u5F0F\u9519\u8BEF: ' + e.message + "</div>";
      }
    };
    document.getElementById("vars-modal").addEventListener("click", function(e) {
      if (e.target === this) closeVarsModal();
    });
    var subscriptions = [];
    var editingSubIdx = -1;
    function loadSubscriptions(cb) {
      ajax("GET", "/subscriptions", null, function(err, data) {
        if (err || !data) {
          subscriptions = [];
        } else {
          subscriptions = data.subscriptions || [];
        }
        if (cb) cb();
      });
    }
    function renderSubList() {
      var listEl = document.getElementById("sub-list");
      if (!listEl) return;
      if (subscriptions.length === 0) {
        listEl.innerHTML = '<div class="empty-state">\u6682\u65E0\u8BA2\u9605\u6E90\uFF0C\u6DFB\u52A0\u4E00\u4E2A\u8BA2\u9605\u94FE\u63A5\u4EE5\u6279\u91CF\u7BA1\u7406\u63D2\u4EF6</div>';
        return;
      }
      var html = "";
      subscriptions.forEach(function(sub, idx) {
        var url = sub.url || "";
        var updatedAt = sub.updatedAt ? new Date(sub.updatedAt).toLocaleString() : "\u672A\u66F4\u65B0";
        var count = typeof sub.pluginCount === "number" && sub.pluginCount > 0 ? sub.pluginCount + " \u4E2A\u63D2\u4EF6" : "";
        var meta = count ? count + " \xB7 \u66F4\u65B0\u4E8E " + updatedAt : "\u66F4\u65B0\u4E8E " + updatedAt;
        var editingCls = idx === editingSubIdx ? " editing" : "";
        html += '<div class="sub-item' + editingCls + '"><div class="sub-item-icon">&#128246;</div><div class="sub-item-info"><div class="sub-item-url">' + escapeHtml(url) + '</div><div class="sub-item-meta">' + escapeHtml(meta) + '</div></div><button class="sub-item-btn" title="\u4FEE\u6539\u8BA2\u9605\u5730\u5740" onclick="editSubscription(' + idx + ')">&#9998;</button><button class="sub-item-btn sub-item-remove" title="\u5220\u9664\u8BA2\u9605" onclick="removeSubscription(' + idx + ')">&times;</button></div>';
      });
      listEl.innerHTML = html;
    }
    function updateInputMode() {
      var addBtn = document.getElementById("sub-add-btn");
      var cancelBtn = document.getElementById("sub-cancel-btn");
      var inputRow = document.querySelector(".sub-input-row");
      var input = document.getElementById("sub-url-input");
      if (editingSubIdx >= 0) {
        addBtn.textContent = "\u4FDD\u5B58\u4FEE\u6539";
        addBtn.classList.add("btn-import");
        cancelBtn.style.display = "";
        inputRow.classList.add("editing");
        input.focus();
      } else {
        addBtn.textContent = "+ \u6DFB\u52A0\u8BA2\u9605";
        addBtn.classList.remove("btn-import");
        cancelBtn.style.display = "none";
        inputRow.classList.remove("editing");
      }
    }
    window.cancelEdit = function() {
      editingSubIdx = -1;
      document.getElementById("sub-url-input").value = "";
      updateInputMode();
      renderSubList();
    };
    window.openSubModal = function() {
      document.getElementById("sub-modal").style.display = "flex";
      editingSubIdx = -1;
      document.getElementById("sub-url-input").value = "";
      updateInputMode();
      loadSubscriptions(function() {
        renderSubList();
      });
    };
    window.openSubModalAndUpdate = function() {
      openSubModal();
      setTimeout(function() {
        updateAllSubscriptions();
      }, 300);
    };
    window.closeSubModal = function() {
      document.getElementById("sub-modal").style.display = "none";
      editingSubIdx = -1;
    };
    document.getElementById("sub-modal").addEventListener("click", function(e) {
      if (e.target === this) closeSubModal();
    });
    window.editSubscription = function(idx) {
      var sub = subscriptions[idx];
      if (!sub) return;
      editingSubIdx = idx;
      document.getElementById("sub-url-input").value = sub.url;
      updateInputMode();
      renderSubList();
    };
    window.addSubscription = function() {
      var input = document.getElementById("sub-url-input");
      var url = (input.value || "").trim();
      if (!url) {
        alert("\u8BF7\u8F93\u5165\u8BA2\u9605\u94FE\u63A5");
        return;
      }
      if (editingSubIdx >= 0) {
        var oldSub = subscriptions[editingSubIdx];
        if (!oldSub) {
          cancelEdit();
          return;
        }
        if (url === oldSub.url) {
          cancelEdit();
          return;
        }
        ajax("PUT", "/subscriptions", { url: oldSub.url, newUrl: url }, function(err, data) {
          if (err || !data) {
            alert("\u4FEE\u6539\u5931\u8D25\uFF08\u7F51\u7EDC\u9519\u8BEF\uFF09");
            return;
          }
          if (data.error) {
            alert(data.error);
            return;
          }
          if (!data.success) {
            alert("\u4FEE\u6539\u5931\u8D25");
            return;
          }
          subscriptions[editingSubIdx] = data.subscription;
          cancelEdit();
        });
        return;
      }
      ajax("POST", "/subscriptions", { url }, function(err, data) {
        if (err || !data) {
          alert("\u6DFB\u52A0\u5931\u8D25\uFF08\u7F51\u7EDC\u9519\u8BEF\uFF09");
          return;
        }
        if (data.error) {
          alert(data.error);
          return;
        }
        if (!data.success) {
          alert("\u6DFB\u52A0\u5931\u8D25");
          return;
        }
        subscriptions.push(data.subscription);
        input.value = "";
        renderSubList();
        updateSubscription(subscriptions.length - 1);
      });
    };
    window.removeSubscription = function(idx) {
      var sub = subscriptions[idx];
      if (!sub) return;
      if (!confirm("\u786E\u8BA4\u5220\u9664\u6B64\u8BA2\u9605\u6E90\uFF1F")) return;
      ajax("DELETE", "/subscriptions", { url: sub.url }, function(err, data) {
        if (err || !data || !data.success) {
          alert("\u5220\u9664\u5931\u8D25");
          return;
        }
        subscriptions.splice(idx, 1);
        renderSubList();
      });
    };
    function fetchSubPlugins(url, callback) {
      var xhr = new XMLHttpRequest();
      xhr.open("GET", url, true);
      xhr.onload = function() {
        try {
          var data = JSON.parse(xhr.responseText);
          var list = [];
          if (Array.isArray(data)) {
            list = data;
          } else if (Array.isArray(data.plugins)) {
            list = data.plugins;
          } else if (Array.isArray(data.data)) {
            list = data.data;
          } else if (Array.isArray(data.list)) {
            list = data.list;
          }
          var urls = list.map(function(item) {
            if (typeof item === "string") return item;
            return item.url || item.link || item.uri || "";
          }).filter(function(u) {
            return u && /^https?:\/\//i.test(u);
          });
          callback(null, urls);
        } catch (e) {
          callback(e, null);
        }
      };
      xhr.onerror = function() {
        callback(new Error("\u7F51\u7EDC\u9519\u8BEF"), null);
      };
      xhr.send();
    }
    function updateSubscription(idx, cb) {
      var sub = subscriptions[idx];
      if (!sub) {
        if (cb) cb();
        return;
      }
      fetchSubPlugins(sub.url, function(err, urls) {
        if (err) {
          alert("\u8BA2\u9605 " + sub.url + " \u83B7\u53D6\u5931\u8D25\uFF1A" + err.message);
          if (cb) cb(err);
          return;
        }
        ajax("PUT", "/subscriptions", { url: sub.url, pluginCount: urls.length }, function() {
          sub.updatedAt = Date.now();
          sub.pluginCount = urls.length;
          renderSubList();
        });
        var i = 0;
        function installNext() {
          if (i >= urls.length) {
            loadPluginList();
            if (cb) cb(null, urls.length);
            return;
          }
          ajax("POST", "/plugins", { url: urls[i], force: true }, function() {
            i++;
            installNext();
          });
        }
        installNext();
      });
    }
    window.updateAllSubscriptions = function() {
      if (subscriptions.length === 0) {
        showToast("\u6682\u65E0\u8BA2\u9605\u6E90", true);
        return;
      }
      var btn = document.querySelector("#sub-modal .modal-footer .btn");
      var progressWrap = document.getElementById("sub-update-progress");
      var progressBar = document.getElementById("sub-update-bar");
      var progressText = document.getElementById("sub-update-text");
      var progressCount = document.getElementById("sub-update-count");
      btn.disabled = true;
      progressWrap.style.display = "";
      progressBar.style.width = "0%";
      progressCount.textContent = "0/" + subscriptions.length;
      var done = 0;
      var total = subscriptions.length;
      function next() {
        if (done >= total) {
          btn.disabled = false;
          progressText.textContent = "\u5168\u90E8\u8BA2\u9605\u5DF2\u66F4\u65B0\u5B8C\u6210";
          progressBar.style.width = "100%";
          progressCount.textContent = total + "/" + total;
          setTimeout(function() {
            progressWrap.style.display = "none";
          }, 3e3);
          return;
        }
        var sub = subscriptions[done];
        progressText.textContent = "\u6B63\u5728\u66F4\u65B0\uFF1A" + (sub.name || sub.url);
        updateSubscription(done, function() {
          done++;
          var pct = Math.round(done / total * 100);
          progressBar.style.width = pct + "%";
          progressCount.textContent = done + "/" + total;
          next();
        });
      }
      next();
    };
    searchResultsWrap.style.display = "none";
    loadHotSongs();
  })();
})();
